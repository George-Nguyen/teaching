# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)

## Artifacts

### E-Learning Platform (`artifacts/elearning`)
- **Type**: React + Vite (frontend-only)
- **Preview path**: `/`
- **Description**: A full e-learning platform featuring:
  - Multi-subject navigation (Navbar dropdown with 4 subjects)
  - Innovation Management course with 3 tabs: Overview, Syllabus, Grading
  - 6 detailed lessons with expandable section cards
  - Lesson progress tracking with "Mark as Complete"
  - Dark mode toggle
  - Responsive, modern UI with sidebar navigation in Syllabus view

### API Server (`artifacts/api-server`)
- Express 5 REST API, health check at `/api/healthz`

### Mockup Sandbox (`artifacts/mockup-sandbox`)
- Design prototyping canvas at `/__mockup`

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.
