import { useState } from "react";
import { LayoutGrid, FileText, Award, Trophy } from "lucide-react";
import LessonSidebar from "@/components/LessonSidebar";
import LessonContent from "@/components/LessonContent";
import OverviewTab from "@/components/OverviewTab";
import GradingTab from "@/components/GradingTab";
import FinalProjectTab from "@/components/FinalProjectTab";
import { innovationCourse } from "@/data/courseData";

type TabId = "overview" | "syllabus" | "grading" | "finalproject";

const tabs: { id: TabId; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: "overview", label: "Tổng quan", icon: LayoutGrid },
  { id: "syllabus", label: "Nội dung", icon: FileText },
  { id: "grading", label: "Chấm điểm", icon: Award },
  { id: "finalproject", label: "Đồ án Cuối kỳ", icon: Trophy },
];

export default function CoursePage() {
  const [activeTab, setActiveTab] = useState<TabId>("overview");
  const [activeLesson, setActiveLesson] = useState(innovationCourse.lessons[0].id);
  const [completedLessons, setCompletedLessons] = useState<Set<string>>(new Set());

  const currentLesson = innovationCourse.lessons.find((l) => l.id === activeLesson)!;
  const currentLessonIndex = innovationCourse.lessons.findIndex((l) => l.id === activeLesson);

  const markComplete = (lessonId: string) => {
    setCompletedLessons((prev) => new Set([...prev, lessonId]));
  };

  const goNext = () => {
    const nextIdx = currentLessonIndex + 1;
    if (nextIdx < innovationCourse.lessons.length) {
      setActiveLesson(innovationCourse.lessons[nextIdx].id);
    }
  };

  const goPrev = () => {
    const prevIdx = currentLessonIndex - 1;
    if (prevIdx >= 0) {
      setActiveLesson(innovationCourse.lessons[prevIdx].id);
    }
  };

  const handleSelectLesson = (lessonId: string) => {
    setActiveLesson(lessonId);
    if (activeTab !== "syllabus") setActiveTab("syllabus");
  };

  return (
    <div className="flex flex-col h-full">
      {/* Course header + tabs */}
      <div className="border-b border-border bg-card px-6 pt-5 pb-0">
        <div className="text-xs font-medium text-muted-foreground mb-1">{innovationCourse.subtitle}</div>
        <h1 className="text-lg font-bold text-foreground font-serif" data-testid="course-title">
          {innovationCourse.title}
        </h1>

        {/* Tabs */}
        <div className="flex gap-1 mt-4" data-testid="course-tabs">
          {tabs.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors relative top-px
                ${activeTab === id
                  ? id === "finalproject"
                    ? "border-amber-500 text-amber-600 dark:text-amber-400"
                    : "border-primary text-primary"
                  : "border-transparent text-muted-foreground hover:text-foreground hover:border-muted-foreground/30"
                }`}
              data-testid={`tab-${id}`}
            >
              <Icon className="w-3.5 h-3.5" />
              {label}
              {id === "finalproject" && (
                <span className="ml-1 inline-flex items-center rounded-full bg-amber-100 dark:bg-amber-900/40 px-1.5 py-0.5 text-[10px] font-bold text-amber-700 dark:text-amber-400 leading-none">
                  NEW
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Tab content */}
      <div className="flex flex-1 overflow-hidden">
        {activeTab === "overview" && (
          <div className="flex-1 overflow-y-auto">
            <OverviewTab course={innovationCourse} />
          </div>
        )}

        {activeTab === "syllabus" && (
          <>
            <LessonSidebar
              lessons={innovationCourse.lessons}
              activeLesson={activeLesson}
              onSelectLesson={handleSelectLesson}
              completedLessons={completedLessons}
            />
            <LessonContent
              lesson={currentLesson}
              lessonIndex={currentLessonIndex}
              totalLessons={innovationCourse.lessons.length}
              isCompleted={completedLessons.has(activeLesson)}
              onMarkComplete={markComplete}
              onNext={goNext}
              onPrev={goPrev}
            />
          </>
        )}

        {activeTab === "grading" && (
          <div className="flex-1 overflow-y-auto">
            <GradingTab course={innovationCourse} />
          </div>
        )}

        {activeTab === "finalproject" && (
          <FinalProjectTab />
        )}
      </div>
    </div>
  );
}
