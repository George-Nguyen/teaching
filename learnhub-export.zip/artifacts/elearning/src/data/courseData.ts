export interface Lesson {
  id: string;
  title: string;
  duration: string;
  content: LessonContent;
}

export interface LessonContent {
  overview: string;
  sections: Section[];
}

export interface Section {
  heading: string;
  body: string;
  type?: "quote" | "list" | "normal";
  items?: string[];
}

export interface CourseTab {
  id: string;
  label: string;
}

export interface Course {
  id: string;
  title: string;
  subtitle: string;
  instructor: string;
  instructorTitle: string;
  description: string;
  objectives: string;
  lessonsCount: number;
  duration: string;
  grading: GradingInfo;
  lessons: Lesson[];
}

export interface GradingInfo {
  scale: GradeEntry[];
  passCondition: string;
}

export interface GradeEntry {
  grade: string;
  range: string;
  color: string;
}

export interface Subject {
  id: string;
  title: string;
  code: string;
  active: boolean;
  available: boolean;
}

export const subjects: Subject[] = [
  { id: "innovation", title: "Innovation & Change Management", code: "IM401", active: true, available: true },
  { id: "marketing", title: "Marketing Foundation", code: "MK201", active: false, available: false },
  { id: "finance", title: "Corporate Finance", code: "CF301", active: false, available: false },
  { id: "hr", title: "Human Resources", code: "HR201", active: false, available: false },
];

export const innovationCourse: Course = {
  id: "innovation",
  title: "Đổi mới và Quản trị Sự thay đổi",
  subtitle: "IM401 · Xuân 2026",
  instructor: "George Nguyen",
  instructorTitle: "Serial Entrepreneur · Blockchain + AI · Giảng viên RMIT",
  description:
    "Khám phá chuyên sâu cách các tổ chức điều hướng sự gián đoạn, nuôi dưỡng sáng tạo và xây dựng văn hóa duy trì lợi thế cạnh tranh thông qua đổi mới và quản trị sự thay đổi có chủ đích.",
  objectives:
    "Môn học nghiên cứu các nguyên lý đổi mới và quản trị sự thay đổi trong kinh tế học, khởi nghiệp và các ngành sáng tạo. Môn học cung cấp cả khung lý thuyết lẫn kỹ thuật thực tiễn, giúp học viên hiểu cách thúc đẩy đổi mới có ý nghĩa và dẫn dắt sự chuyển đổi tổ chức trong môi trường thực tế.",
  lessonsCount: 15,
  duration: "15 tuần",
  grading: {
    scale: [
      { grade: "A", range: "90 – 100", color: "bg-emerald-500" },
      { grade: "B", range: "80 – 89", color: "bg-blue-500" },
      { grade: "C", range: "70 – 79", color: "bg-yellow-500" },
      { grade: "D", range: "60 – 69", color: "bg-orange-500" },
      { grade: "F", range: "< 60", color: "bg-red-500" },
    ],
    passCondition:
      "Học viên phải đạt tổng điểm từ 61 trở lên trước hạn nộp bài đầu tiên để qua môn. Bài nộp trễ sẽ bị trừ điểm theo quy định.",
  },
  lessons: [
    {
      id: "lesson-1",
      title: "Giới thiệu — Duy trì Sáng tạo",
      duration: "45 phút",
      content: {
        overview:
          "Chúng ta bắt đầu với một thách thức: hầu hết chúng ta ngừng sáng tạo trước khi thực sự cạn kiệt ý tưởng. Bài học đầu tiên này giúp bạn khám phá lại tư duy nuôi dưỡng những công việc xuất sắc.",
        sections: [
          {
            heading: "Câu nói truyền cảm hứng",
            type: "quote",
            body: `"Nếu bạn muốn điều gì đó mới, bạn phải dừng làm điều gì đó cũ." — Peter F. Drucker\n\n"Cách duy nhất để khám phá giới hạn của điều có thể là vượt qua nó vào điều không thể." — Arthur C. Clarke`,
            items: [],
          },
          {
            heading: "Kỹ năng Công ty Cần Nhất — 2020",
            type: "list",
            body: "LinkedIn Learning & WEF xếp hạng các kỹ năng quan trọng nhất mà doanh nghiệp tìm kiếm:\n\nKỹ năng Mềm (Soft Skills):",
            items: [
              "1. Sáng tạo (Creativity) — kỹ năng mềm số 1",
              "2. Thuyết phục & Lãnh đạo (Persuasion & Leadership)",
              "3. Cộng tác (Collaboration)",
              "4. Thích nghi (Adaptability)",
              "5. Trí tuệ Cảm xúc (Emotional Intelligence)",
              "─── Kỹ năng Cứng (Hard Skills): ───",
              "1. Blockchain",
              "2. Điện toán Đám mây (Cloud Computing)",
              "3. Tư duy Phân tích (Analytical Reasoning)",
              "4. Trí tuệ Nhân tạo (Artificial Intelligence)",
              "5. Design Thinking",
              "6. Business Analysis",
              "7. Affiliate Marketing & Influencer",
              "8. Sales",
              "9. Lập trình Khoa học (Python, Scientific Computing)",
              "10. Sản xuất Video (Video Production)",
            ],
          },
          {
            heading: "Tại sao Sáng tạo là Kỹ năng Số 1",
            type: "normal",
            body: "Nghiên cứu liên tục chỉ ra rằng sáng tạo là kỹ năng mềm hàng đầu mà các doanh nghiệp cần — vượt qua làm việc nhóm, trí tuệ cảm xúc và năng lực kỹ thuật. Trong một thế giới mà tự động hóa đang xử lý các công việc thường ngày, sáng tạo của con người là lợi thế cạnh tranh thực sự cuối cùng.",
          },
          {
            heading: "Môn học này bao gồm những gì",
            type: "list",
            body: "",
            items: [
              "Bản chất của đổi mới và lý do tại sao nó quan trọng hơn bao giờ hết",
              "Tư duy sáng tạo thực sự hoạt động như thế nào trong não bộ",
              "Các rào cản tổ chức tiêu diệt đổi mới — và cách tháo gỡ chúng",
              "Xây dựng văn hóa nơi những ý tưởng mới có thể phát triển",
              "Công cụ và khung thực tiễn được sử dụng bởi các công ty đẳng cấp thế giới",
            ],
          },
          {
            heading: "Bài tập của bạn",
            type: "normal",
            body: "Hãy suy ngẫm về lần cuối cùng bạn có một ý tưởng thực sự độc đáo. Điều kiện nào đã tạo ra nó? Thời điểm đó khác gì so với ngày làm việc bình thường của bạn? Hãy viết một bài phản ánh ngắn 300 từ và chuẩn bị để thảo luận trong buổi học tiếp theo.",
          },
        ],
      },
    },
    {
      id: "lesson-2",
      title: "Các Khái niệm Cơ bản",
      duration: "60 phút",
      content: {
        overview:
          "Đổi mới không phải là phép màu — đó là quản lý có kỷ luật về nguồn lực, quy trình và văn hóa tổ chức để tạo ra điều gì đó thực sự mới và có giá trị. Bài học này xây dựng vốn từ vựng nền tảng.",
        sections: [
          {
            heading: "Đổi mới ở Khắp Nơi — Ví dụ Thực tế",
            type: "list",
            body: "Đổi mới không chỉ xảy ra trong phòng lab — nó xuất hiện trong mọi lĩnh vực cuộc sống:",
            items: [
              "Bếp Robot hóa (Robotic Kitchen) — Nấu ăn tự động hoàn toàn không cần đầu bếp",
              "Giao hàng bằng Drone — Amazon, DHL và nhiều startup thử nghiệm giao hàng không người",
              "Amazon Go — Cửa hàng không cần thu ngân, tự động tính tiền qua AI và camera",
              "Photomath — App chụp bài toán và giải ngay lập tức",
              "Dịch thuật Tức thì (Instant Translation) — Google Lens dịch ký tự trong ảnh thời gian thực",
              "Dự báo Thời tiết AR — Trực quan hóa mây, mưa theo thực tế tăng cường",
              "Robot Olympics Tokyo 2020 — Robot phục vụ khán giả, hỗ trợ vận động viên khuyết tật",
            ],
          },
          {
            heading: "Đổi mới là gì?",
            type: "normal",
            body: "Đổi mới mang lại lợi thế cạnh tranh thông qua quản lý hiệu quả nguồn lực, quy trình và văn hóa tổ chức. Đó không chỉ là phát minh đơn thuần — mà là phát minh kết hợp với triển khai thành công và tạo ra giá trị.\n\nĐổi mới là quá trình: Khám phá cơ hội → Tìm cách khai thác cơ hội → Triển khai ý tưởng để đạt kết quả đo lường được. Ý tưởng tốt chưa đủ — phần lớn ý tưởng xuất sắc không bao giờ được thực thi.",
          },
          {
            heading: "Ba loại Đổi mới — Clayton Christensen",
            type: "list",
            body: "Clayton Christensen (Harvard Business School) phân loại 3 loại đổi mới theo tác động chiến lược:",
            items: [
              "1. Đổi mới Hiệu quả (Efficiency Innovation) — Làm cùng một việc nhưng nhanh hơn hoặc rẻ hơn. Ví dụ: tự động hóa quy trình, tối ưu chuỗi cung ứng. Tạo ra ít việc làm mới.",
              "2. Đổi mới Duy trì (Sustaining Innovation) — Cải thiện sản phẩm/dịch vụ hiện có cho khách hàng hiện tại. Ví dụ: nâng cấp smartphone từng phiên bản. Duy trì thị phần, không tạo ra thị trường mới.",
              "3. Đổi mới Gián đoạn (Disruptive Innovation) — Biến giải pháp phức tạp thành sản phẩm/dịch vụ mới, đơn giản và vượt trội. Ví dụ: Airbnb, Netflix, smartphone ban đầu. Tạo ra thị trường hoàn toàn mới, phá vỡ ngành hiện có.",
            ],
          },
          {
            heading: "Công nghệ Gián đoạn Đang định hình Thế giới",
            type: "list",
            body: "Các công nghệ này đang làm gián đoạn các ngành công nghiệp đã được thiết lập:",
            items: [
              "Robot hóa — Tự động hóa lao động vật lý trong sản xuất, logistics, chăm sóc sức khỏe",
              "IoT (Internet of Things) — Kết nối các vật thể vật lý với trí tuệ kỹ thuật số",
              "Trí tuệ Nhân tạo — Chuyển đổi ra quyết định, sáng tạo và phân tích",
              "Blockchain — Phi tập trung hóa niềm tin và lưu trữ hồ sơ",
              "In 3D — Sản xuất theo yêu cầu ở mọi quy mô",
              "Máy bay không người lái — Giao hàng tự chủ, giám sát và thu thập dữ liệu",
            ],
          },
          {
            heading: "Ý tưởng Xuất sắc đến từ đâu?",
            type: "list",
            body: "Dữ liệu làm nhiều người ngạc nhiên. Ý tưởng không chủ yếu được sinh ra trong các phòng R&D:",
            items: [
              "40% đổi mới xuất phát từ nhân viên tuyến đầu",
              "38% đến từ đối tác và khách hàng quan sát nhu cầu thực tế",
              "Chỉ 17% xuất hiện từ các quy trình R&D chính thức",
            ],
          },
          {
            heading: "Đổi mới Ngẫu nhiên",
            type: "normal",
            body: "Một số đổi mới quan trọng nhất trong lịch sử là những khám phá tình cờ — lò vi sóng (Percy Spencer nhận thấy sóng radar làm tan chảy thanh sô cô la của ông), penicillin (đĩa Petri bị nhiễm khuẩn của Alexander Fleming), và giấy ghi chú Post-it (keo yếu 'thất bại' của Spencer Silver). Bài học: tạo ra môi trường nơi những khám phá bất ngờ có thể được nhận ra và hành động.",
          },
          {
            heading: "7 C của Tư duy Đổi mới",
            type: "list",
            body: "Khung để xây dựng và duy trì tư duy đổi mới:",
            items: [
              "Tò mò (Curiosity) — Đặt câu hỏi về mọi thứ, không coi điều gì là vĩnh cửu",
              "Văn hóa (Culture) — Xây dựng môi trường nơi ý tưởng được an toàn để chia sẻ",
              "Kết nối (Connecting) — Kết hợp ý tưởng từ các lĩnh vực khác nhau",
              "Sáng tạo (Creativity) — Tạo ra khả năng trước khi đánh giá chúng",
              "Dũng cảm (Courage) — Hành động bất chấp sự không chắc chắn và rủi ro thất bại",
              "Giao tiếp (Communication) — Chia sẻ ý tưởng rõ ràng và truyền cảm hứng cho người khác",
              "Quản trị Sự thay đổi (Change Management) — Hướng dẫn các tổ chức qua sự chuyển đổi",
            ],
          },
        ],
      },
    },
    {
      id: "lesson-3",
      title: "Đổi mới và Giáo dục",
      duration: "50 phút",
      content: {
        overview:
          "Các thể chế hình thành cách chúng ta học được thiết kế cho một thế giới không còn tồn tại nữa. Bài học này xem xét lý do tại sao giáo dục phải chuyển đổi — và một mô hình tốt hơn trông như thế nào.",
        sections: [
          {
            heading: "Kỷ nguyên Augmented (Tăng cường)",
            type: "normal",
            body: "Chúng ta đang bước vào Kỷ nguyên Augmented nơi con người và máy móc cùng làm việc. Kỷ nguyên này không khen thưởng sự phục tùng và lặp lại — mà khen thưởng sự sáng tạo, linh hoạt và thích nghi. Như triết gia Heraclitus quan sát: sự thay đổi là hằng số duy nhất. Những tổ chức và cá nhân thịnh vượng là những người đã biến sự thích nghi thành năng lực cốt lõi.",
          },
          {
            heading: "Người lao động Mới",
            type: "list",
            body: "Mô hình lao động thời công nghiệp coi trọng sự phục tùng và siêng năng trên hết. Nền kinh tế mới đòi hỏi điều gì đó hoàn toàn khác:",
            items: [
              "Đam mê (Passion) — Động lực nội tại, không chỉ là tuân thủ",
              "Sáng tạo (Creativity) — Khả năng tạo ra giải pháp mới, không chỉ làm theo quy trình",
              "Chủ động (Initiative) — Động lực để xác định vấn đề và hành động mà không cần được bảo",
            ],
          },
          {
            heading: "Những Sai lầm của Giáo dục Truyền thống",
            type: "list",
            body: "Các hệ thống giáo dục truyền thống chứa đựng những giả định ăn sâu làm tê liệt đổi mới:",
            items: [
              "Tách rời học tập khỏi công việc — như thể kiến thức và thực hành là những hoạt động khác nhau",
              "Dạy lý tính trong khi không khuyến khích sự gián đoạn — tạo ra phân tích mà không có hành động",
              "Tối ưu hóa cho thành công quan liêu thay vì tư duy khởi nghiệp",
              "Chấm điểm sự tuân thủ thay vì khen thưởng tư duy nguyên bản",
            ],
          },
          {
            heading: "Kỹ năng Đọc mới: Học → Bỏ học → Tái học",
            type: "normal",
            body: "Nhà tương lai học Alvin Toffler định nghĩa kỹ năng đọc mới không phải là đọc và viết, mà là khả năng Học, Bỏ học và Tái học. Chu kỳ ba bước này là cách các cá nhân duy trì sự liên quan trong một thế giới thay đổi nhanh chóng.",
          },
          {
            heading: "Giải thích Ba Bước",
            type: "list",
            body: "",
            items: [
              "Học (Learn) — Tiếp thu kiến thức, kỹ năng và khung mới",
              "Bỏ học (Unlearn) — Có chủ ý gạt bỏ các giả định và thói quen không còn phục vụ bạn (đây là bước khó nhất — đòi hỏi sự khiêm tốn trí tuệ)",
              "Tái học (Relearn) — Xây dựng mô hình tư duy mới trên nền tảng đã được làm sạch",
            ],
          },
          {
            heading: "Bài tập Suy ngẫm",
            type: "normal",
            body: "Một giả định bạn có về ngành hoặc lĩnh vực của mình cần được 'bỏ học' là gì? Điều gì sẽ thay đổi nếu bạn buông bỏ nó?",
          },
        ],
      },
    },
    {
      id: "lesson-4",
      title: "Cách Tư duy Sáng tạo",
      duration: "55 phút",
      content: {
        overview:
          "Sáng tạo không phải là đặc điểm tính cách — đó là một kỹ năng. Và như mọi kỹ năng, nó có thể được hiểu, thực hành và cải thiện. Bài học này khám phá khoa học nhận thức đằng sau tư duy sáng tạo.",
        sections: [
          {
            heading: "Hai Chế độ Tư duy",
            type: "normal",
            body: "Não bộ hoạt động theo hai chế độ hoàn toàn khác nhau. Hiểu chúng — và biết khi nào dùng từng loại — là chìa khóa cho công việc sáng tạo có chủ đích.",
          },
          {
            heading: "Tư duy Hội tụ (Convergent)",
            type: "normal",
            body: "Tư duy hội tụ sử dụng bán cầu não trái. Nó mang tính logic, phân tích, tuần tự và dựa trên quy tắc. Đây là chế độ của bài kiểm tra IQ, chiến lược cờ vua, lý luận thám tử (Sherlock Holmes) và giải quyết vấn đề kỹ thuật. Tư duy hội tụ xuất sắc trong việc đánh giá ý tưởng — nhưng không thể tạo ra chúng.",
          },
          {
            heading: "Tư duy Phân kỳ (Divergent)",
            type: "normal",
            body: "Tư duy phân kỳ sử dụng trí tưởng tượng, trực giác và liên tưởng tự do. Nó tạo ra nhiều khả năng thay vì hội tụ vào một giải pháp. Thomas Edison nổi tiếng đã sử dụng chế độ này — ông thử hàng trăm vật liệu trước khi tìm ra sợi tóc đèn đúng. Thiền định, mơ mộng và viết tự do đều là những thực hành kích hoạt tư duy phân kỳ.",
          },
          {
            heading: "Quá trình Sáng tạo: Các Bước",
            type: "list",
            body: "Sáng tạo không xuất hiện ngẫu nhiên — nó tuân theo một trình tự có thể nhận ra được:",
            items: [
              "1. Xác định Vấn đề — Diễn đạt rõ ràng bạn đang cố giải quyết gì",
              "2. Bối rối — Đắm chìm vào vấn đề cho đến khi nó cảm thấy thực sự khó khăn",
              "3. Ủ tư duy (Incubation) — Lùi lại. Để tâm trí tiềm thức làm việc (ngủ, đi bộ, tắm)",
              "4. The Aha Moment — Sự hiểu biết đột ngột, thường đến bất ngờ",
              "5. Xác minh — Kiểm tra và tinh chỉnh sự hiểu biết bằng tư duy hội tụ",
            ],
          },
          {
            heading: "The Aha Moment",
            type: "normal",
            body: "The Aha Moment — còn gọi là insight hay eureka — là sự nhận thức đột ngột, bất ngờ tái định hình vấn đề hoặc mở ra con đường giải pháp. Newton quan sát quả táo rơi, Einstein tưởng tượng như thế nào khi cưỡi song song với chùm ánh sáng: đây là những The Aha Moment kinh điển. Khoa học thần kinh cho thấy chúng đi kèm với sự tăng đột biến đặc trưng của sóng gamma trong bán cầu phải — não của bạn thực sự 'sáng lên'.",
          },
          {
            heading: "Thực hành Hỗ trợ Tư duy Sáng tạo",
            type: "list",
            body: "Thói quen thực tế kích hoạt tư duy phân kỳ:",
            items: [
              "Vận động thể chất thường xuyên — walking meetings, đi bộ, thể dục đều kích hoạt não sáng tạo",
              "Đọc đa lĩnh vực — ý tưởng va chạm xuyên các ngành",
              "Chánh niệm và thiền định",
              "Viết nhật ký và viết tự do không tự kiểm duyệt",
              "Dành thời gian trong môi trường mới hoặc xa lạ",
              "Bảo vệ thời gian không có cấu trúc — lên lịch 'thời gian suy nghĩ'",
            ],
          },
        ],
      },
    },
    {
      id: "lesson-5",
      title: "Rào cản & Trở ngại đối với Sáng tạo",
      duration: "60 phút",
      content: {
        overview:
          "Hiểu tại sao sáng tạo thất bại trong các tổ chức cũng quan trọng như hiểu cách nuôi dưỡng nó. Bài học này liệt kê các rào cản phổ biến và gây hại nhất — và cách các công ty đẳng cấp thế giới đã tháo gỡ chúng.",
        sections: [
          {
            heading: "5 Rào cản Chính đối với Đổi mới",
            type: "normal",
            body: "Năm trở ngại này xuất hiện trong các tổ chức ở mọi quy mô và ngành. Nhận ra chúng là bước đầu tiên để vô hiệu hóa chúng.",
          },
          {
            heading: "1. Bác bỏ Ý tưởng của Người khác",
            type: "normal",
            body: "Bản năng bảo vệ hiện trạng rất mạnh mẽ. Mọi người bảo vệ cách mọi thứ đang diễn ra vì họ đã đầu tư thời gian và công sức xây dựng nó — hiệu ứng 'chi phí chìm'. Các tổ chức phản xạ bác bỏ ý tưởng mới phát tín hiệu cho nhân viên rằng đóng góp là rủi ro. Kết quả: ý tưởng ngừng được chia sẻ.",
          },
          {
            heading: "2. Quan liêu và Thủ tục Hành chính",
            type: "normal",
            body: "Thủ tục quá mức, chuỗi phê duyệt và sợ vi phạm quy trình là những kẻ giết đổi mới. Khi mỗi ý tưởng mới cần sáu chữ ký và đánh giá rủi ro, hầu hết ý tưởng chết trong ủy ban. Quan liêu thường là hệ thống miễn dịch tổ chức tấn công các tế bào mới lành mạnh.",
          },
          {
            heading: "3. Thiếu Nguồn lực",
            type: "list",
            body: "Đổi mới đòi hỏi đầu tư. Ba ràng buộc nguồn lực thường được trích dẫn nhất là:",
            items: [
              "Kinh phí — Không có ngân sách cho thử nghiệm nghĩa là không có thử nghiệm",
              "Nhân lực — Đổi mới không thể bị nhét vào khối lượng công việc đã đầy",
              "Thời gian — Sự khẩn cấp là kẻ thù của sáng tạo; thời gian nhàn rỗi là thiết yếu",
            ],
          },
          {
            heading: "4. Fachidiotism (Hội chứng Chuyên môn Hẹp)",
            type: "normal",
            body: "Fachidiotism — một khái niệm tiếng Đức — mô tả tình trạng biết quá nhiều về chuyên môn của bạn đến mức mất khả năng nhìn bức tranh tổng thể. Chuyên môn sâu trở thành trách nhiệm khi nó tạo ra tầm nhìn nhận thức hạn hẹp. Các giải pháp đổi mới nhất thường đến từ những người kết hợp thông tin từ nhiều lĩnh vực — những người hình chữ T hơn là hình chữ I.",
          },
          {
            heading: "5. Sợ Thất bại",
            type: "normal",
            body: "Trong các văn hóa trừng phạt thất bại, mọi người chọn các lựa chọn an toàn và tìm kẻ thế tội khi mọi thứ sai. Đổi mới vốn đã không chắc chắn — nó đòi hỏi rủi ro. Không có sự an toàn tâm lý để thất bại, các tổ chức có được sự tuân thủ, không phải sự sáng tạo.",
          },
          {
            heading: "Mô hình Google: Smart Creatives",
            type: "list",
            body: "Google đã xây dựng một trong những động cơ đổi mới nhất quán nhất trong lịch sử. Cách tiếp cận của họ chắt lọc thành ba nguyên tắc:",
            items: [
              "Tin tưởng là văn hóa cốt lõi — Sự minh bạch triệt để và an toàn tâm lý là không thể thương lượng; mỗi nhân viên được đối xử như một người lớn thông minh",
              "Quy tắc 20% — Kỹ sư dành 20% thời gian của họ cho các dự án cá nhân theo lựa chọn của họ. Thất bại được tôn vinh như bằng chứng của việc cố gắng điều gì đó táo bạo. Gmail, AdSense và Google News đều bắt đầu như các dự án 20%",
              "Tuyển dụng dựa trên giá trị trước — Kỹ năng có thể được dạy; sự tò mò trí tuệ, sự thoải mái với sự không chắc chắn và phù hợp với các giá trị cốt lõi thì không thể. Phù hợp văn hóa không phải về tính cách — mà là về các nguyên tắc chung",
            ],
          },
        ],
      },
    },
    {
      id: "lesson-6",
      title: "Văn hóa Đổi mới",
      duration: "55 phút",
      content: {
        overview:
          "Chiến lược không có văn hóa chỉ là một tài liệu. Bài học cuối cùng xem xét điều gì phân biệt các tổ chức duy trì đổi mới trong nhiều thập kỷ — và cách họ làm điều đó.",
        sections: [
          {
            heading: "Đặc điểm của Văn hóa Đổi mới",
            type: "list",
            body: "Các tổ chức đổi mới đáng tin cậy nhất chia sẻ những đặc điểm này:",
            items: [
              "Kaizen (Cải tiến Liên tục) — Cải tiến nhỏ, từng bước mỗi ngày, được thúc đẩy bởi tất cả mọi người, không chỉ ban quản lý",
              "Hỗ trợ từ trên xuống — Lãnh đạo làm gương thử nghiệm, chấp nhận thất bại và bảo vệ đổi mới khỏi áp lực tài chính ngắn hạn",
              "Tạo ra ý tưởng chủ động — Các hệ thống chính thức và không chính thức để thu thập và phát triển ý tưởng mới từ tất cả cấp bậc",
              "An toàn tâm lý — Mọi người cảm thấy an toàn khi lên tiếng, thách thức các giả định và chia sẻ ý tưởng chưa hoàn chỉnh mà không bị chế nhạo",
              "Tôn vinh học tập — Cả thành công và thất bại đều được nghiên cứu và chia sẻ công khai",
            ],
          },
          {
            heading: "Thực hành Tốt nhất: Google",
            type: "normal",
            body: "Google cho các kỹ sư một ngày mỗi tuần (thời gian 20%) để làm việc với bất cứ điều gì họ quan tâm. Không cần kết quả bàn giao. Đầu ra đã bao gồm một số sản phẩm thành công nhất của công ty. Tín hiệu này gửi đi rất mạnh mẽ: sự tò mò của bạn có giá trị tổ chức.",
          },
          {
            heading: "Thực hành Tốt nhất: Netflix",
            type: "normal",
            body: "Netflix hoạt động theo nguyên tắc tự do và trách nhiệm triệt để. Không có cấu trúc quản lý vi mô, không có chuỗi phê duyệt cho các quyết định thông thường. Nhân viên được đối xử như người lớn có thể được tin tưởng với bối cảnh và quyền tự chủ. 'Netflix Culture Deck' là một trong những tài liệu doanh nghiệp có ảnh hưởng nhất từng được xuất bản — nó mô tả một văn hóa hiệu suất cao và tự do cao đồng thời.",
          },
          {
            heading: "Thực hành Tốt nhất: Disney",
            type: "normal",
            body: "Triết lý đổi mới của Disney đơn giản một cách lừa đảo: 'biến trí tưởng tượng thành hiện thực'. Điều này thể hiện trong các quy trình sáng tạo chuyên dụng như 'Imagineering' — một ngành kết hợp độ chính xác kỹ thuật với tầm nhìn nghệ thuật. Các công viên, phim và trải nghiệm của Disney được xây dựng trên niềm tin rằng nếu bạn có thể mơ đủ rõ ràng, bạn có thể xây dựng nó.",
          },
          {
            heading: "Thực hành Tốt nhất: Sony",
            type: "normal",
            body: "Sony về mặt lịch sử đã tạo ra các 'hộp cát' nội bộ — các không gian và ngân sách thời gian dành riêng để các kỹ sư thử nghiệm tự do mà không có áp lực kinh doanh trực tiếp. Triết lý này đã tạo ra Walkman, PlayStation và nhiều công nghệ âm thanh đã định hình lại toàn bộ thị trường. Bài học: cho những người tài năng quyền để chơi.",
          },
          {
            heading: "Xây dựng Văn hóa Đổi mới của Bạn",
            type: "list",
            body: "Dù bạn là trưởng nhóm, doanh nhân hay người đóng góp cá nhân, bạn có thể áp dụng các nguyên tắc này ở quy mô của mình:",
            items: [
              "Tạo ra các không gian thường xuyên cho ý tưởng không có cấu trúc — hàng tuần, không phải hàng quý",
              "Phản ứng với ý tưởng tệ bằng sự tò mò, không phải bác bỏ",
              "Chia sẻ câu chuyện thất bại cởi mở như câu chuyện thành công",
              "Loại bỏ ít nhất một trở ngại quan liêu mỗi quý",
              "Công nhận và khen thưởng những người thách thức hiện trạng, ngay cả khi ý tưởng của họ thất bại",
            ],
          },
          {
            heading: "Suy nghĩ Kết thúc Phần I",
            type: "normal",
            body: "Đổi mới không phải là một bộ phận, một dòng ngân sách, hay một cuộc thi hackathon mỗi năm. Đó là một thực hành hàng ngày, một cam kết văn hóa và một kỷ luật tổ chức. Các công ty và con người sẽ định hình thập kỷ tiếp theo đã đang thực hành nó — không chờ đợi sự cho phép, không chờ đợi điều kiện hoàn hảo, và không sợ những thất bại không thể tránh khỏi trên đường đi. Hãy bắt đầu ngay bây giờ.",
          },
        ],
      },
    },

    // ─── PHẦN I MỞ RỘNG: KỸ THUẬT SÁNG TẠO & KINH TẾ SÁNG TẠO ──────────────────

    {
      id: "lesson-creativity-boosting",
      title: "Kỹ thuật Thúc đẩy Sáng tạo (Creativity Boosting)",
      duration: "65 phút",
      content: {
        overview:
          "Sáng tạo không chỉ là năng khiếu bẩm sinh — đó là kỹ năng có thể đo lường, rèn luyện và cải thiện có hệ thống. Bài học này giới thiệu các kỹ thuật cá nhân và nhóm được thiết kế để khai phá tiềm năng sáng tạo trong thực tiễn công việc.",
        sections: [
          {
            heading: "Câu chuyện Con Ếch và Con Cú — Tư duy Cởi mở",
            type: "normal",
            body: "Một con ếch nhỏ sống dưới đáy giếng tưởng rằng bầu trời chỉ to bằng miệng giếng. Một con cú bay qua nhìn xuống và thấy một thực tế hoàn toàn khác. Câu chuyện này là ẩn dụ cốt lõi của tư duy sáng tạo: khả năng thoát ra khỏi 'giếng' của chính mình — những giả định, thói quen và góc nhìn hạn hẹp — để nhìn thấy bức tranh rộng hơn. Sáng tạo bắt đầu từ sự khiêm tốn nhận ra rằng mình chưa nhìn thấy hết.",
          },
          {
            heading: "Sáng tạo có thể Đo lường và Kiểm tra",
            type: "list",
            body: "Sáng tạo không phải là điều huyền bí — nó có thể được đánh giá qua ba chiều:",
            items: [
              "Kỹ năng Sáng tạo (Creative Skills) — khả năng tạo ra ý tưởng mới, kết nối các khái niệm không liên quan, giải quyết vấn đề theo cách độc đáo",
              "Sản lượng Sáng tạo (Creative Production) — số lượng và chất lượng ý tưởng được tạo ra trong một khoảng thời gian nhất định",
              "Thái độ và Hành vi Sáng tạo (Creative Attitude) — sự cởi mở với trải nghiệm mới, chấp nhận rủi ro, chịu đựng sự mơ hồ",
            ],
          },
          {
            heading: "Các Kỹ thuật Cá nhân (Individual Techniques)",
            type: "list",
            body: "Bộ công cụ kỹ thuật cá nhân để kích hoạt tư duy sáng tạo:",
            items: [
              "Analogy (Phép loại suy) — tìm điểm tương đồng giữa vấn đề của bạn và một thứ hoàn toàn khác",
              "Learning by Imitation (Học qua Bắt chước) — quan sát và mô phỏng cách người khác giải quyết vấn đề tương tự",
              "Free Associations (Liên kết Tự do) — từ một từ khóa, để tâm trí liên kết tự do không kiểm duyệt",
              "Trigger Metaphors (Ẩn dụ Kích hoạt) — định nghĩa vấn đề bằng một ẩn dụ, sau đó phân tích ẩn dụ đó",
              "List of Questions (Danh sách Câu hỏi) — đặt hàng loạt câu hỏi What/Why/How/Who/Where về vấn đề",
              "Funny Questions (Câu hỏi Hài hước) — đặt những câu hỏi vô lý để phá vỡ tư duy thông thường",
              "Personification (Nhân cách hóa) — coi vấn đề như một con người, nó cảm thấy gì, muốn gì?",
              "Mash-up / Forced Relationships — kết hợp hai thứ hoàn toàn không liên quan để tạo ý tưởng mới",
              "Input–Output Method — xác định rõ đầu vào (hiện trạng), đầu ra mong muốn, rồi thiết kế quy trình kết nối",
            ],
          },
          {
            heading: "Kỹ thuật Liên kết Tự do — Ví dụ thực tế",
            type: "normal",
            body: "Bài toán: Một quán cà phê không có khách. Từ khóa được chọn: 'vui vẻ, giải trí'.\n\nChuỗi liên kết tự do: tâm trạng tốt → ca hát → nhạc sống → The Beatles → Lady Gaga → âm nhạc đường phố → yoga → Nhật Bản → geisha → trải nghiệm đặc biệt → cách ly khỏi thế giới ồn ào → đảo hoang → Tahiti → kỳ nghỉ → du thuyền → bác sĩ → cộng đồng...\n\nTừ chuỗi liên kết này: ý tưởng biến quán cà phê thành 'ốc đảo yên tĩnh không wifi, không điện thoại', hoặc tổ chức 'concert acoustic nhỏ hàng tuần', hoặc 'trải nghiệm thiền định cùng cà phê sáng'.",
          },
          {
            heading: "Kỹ thuật Ẩn dụ Kích hoạt — Ví dụ: Ăn pizza",
            type: "list",
            body: "Thách thức: Thiết kế một ứng dụng di động mới. Ẩn dụ được chọn: 'Thiết kế app như ăn pizza'.\n\nPhân tích ẩn dụ — điều gì xảy ra khi ăn pizza?",
            items: [
              "Có thể ăn bằng tay hoặc dao nĩa → App phải có nhiều cách thao tác (cử chỉ, nút bấm)",
              "Cắt thành từng lát → Chia app thành các module nhỏ, dùng từng phần độc lập",
              "Có thể đặt giao tận nơi → App phải hoạt động offline, đồng bộ khi có mạng",
              "Trẻ em rất thích → UI phải đủ đơn giản để mọi đối tượng dùng được",
              "Ngón tay bị dính → Thiết kế tránh thao tác nhiều bước — minimize friction",
            ],
          },
          {
            heading: "Mash-up / Forced Relationships — Kết hợp Bất ngờ",
            type: "list",
            body: "Mash-up mang hai thứ hoàn toàn không liên quan lại với nhau để tạo ra ý tưởng mới. Quy trình 4 bước:",
            items: [
              "Bước 1 — FRAME: Diễn đạt thách thức dạng 'Làm thế nào chúng ta có thể...?' (How Might We?)",
              "Bước 2 — NARROW: Chọn 2 lĩnh vực hoàn toàn không liên quan (ví dụ: bệnh viện + khách sạn, phòng chờ + trường học)",
              "Bước 3 — GENERATE: Liệt kê càng nhiều yếu tố của 2 trải nghiệm đó càng tốt trong 2 phút",
              "Bước 4 — MASH-UP: Kết hợp các yếu tố từ 2 danh sách để tạo ra sản phẩm, dịch vụ hoặc trải nghiệm mới",
              "Ví dụ: Văn phòng chính phủ + Doanh nghiệp tư → công chức = doanh nhân → tư nhân hóa dịch vụ công",
            ],
          },
          {
            heading: "Các Kỹ thuật Nhóm (Group Techniques)",
            type: "list",
            body: "Khi cần khai thác trí tuệ tập thể, các kỹ thuật nhóm phát huy tác dụng mạnh hơn:",
            items: [
              "Brainstorming — đặt ra vấn đề, mọi người tự do đưa ra ý tưởng không phán xét, số lượng quan trọng hơn chất lượng ở giai đoạn đầu",
              "Brainwriting — thay vì nói, viết ý tưởng ra giấy rồi truyền tay nhau, tránh hiệu ứng 'giọng nói to nhất chiếm lĩnh phòng'",
              "Hackathon — sự kiện tập trung cường độ cao (24–72h) với mục tiêu tạo ra prototype cụ thể",
              "Magical Stock-exchange — mọi người 'đầu tư điểm' vào ý tưởng của nhau, ý tưởng nào nhiều 'nhà đầu tư' nhất được ưu tiên phát triển",
              "Synectics — kỹ thuật kết hợp phép loại suy và tư duy liên kết có cấu trúc, thường dùng cho các vấn đề kỹ thuật phức tạp",
            ],
          },
          {
            heading: "Quản lý Truyền thống vs. Quản lý Hiện đại",
            type: "list",
            body: "Trong tổ chức sáng tạo, vai trò người quản lý thay đổi hoàn toàn:\n\nQuản lý truyền thống: Giám sát viên · Cảnh sát · Quan tòa · Kế toán viên\n\nQuản lý hiện đại:",
            items: [
              "Coach (Huấn luyện viên) — phát triển tiềm năng, không kiểm soát hành vi",
              "Conductor (Nhạc trưởng) — phối hợp các bộ phận tạo ra hòa âm chung",
              "Catalyst (Chất xúc tác) — tạo điều kiện để phản ứng sáng tạo xảy ra, không tự mình là phản ứng",
              "Visionary (Người có Tầm nhìn) — vạch ra tương lai hấp dẫn đủ để kéo mọi người theo",
              "Friend (Người bạn) — tin tưởng, hỗ trợ và thành thật với đồng nghiệp",
            ],
          },
        ],
      },
    },

    {
      id: "lesson-creative-economy",
      title: "Kinh tế Sáng tạo và Xã hội (Creative Economy & Society)",
      duration: "50 phút",
      content: {
        overview:
          "Kinh tế Sáng tạo là hệ thống kinh tế nơi giá trị được tạo ra từ sáng tạo và trí tuệ con người, thay vì từ các nguồn lực truyền thống. Bài học này xem xét quy mô toàn cầu của nền kinh tế này và những hàm ý cho tổ chức và xã hội.",
        sections: [
          {
            heading: "Đổi mới trong Thể chế — Tư tưởng của Peter Drucker",
            type: "quote",
            body: '"Tập đoàn như chúng ta biết, hiện đã 120 tuổi, khó có thể tồn tại trong 25 năm tới. Về mặt pháp lý và tài chính — có thể. Nhưng về cấu trúc và kinh tế — không." — Peter Drucker\n\n"Ngân hàng là cần thiết nhưng các ngân hàng thì không!" — Tom Peters',
            items: [],
          },
          {
            heading: "Tổ chức Sáng tạo = Tổ chức Đổi mới",
            type: "list",
            body: "Các tổ chức được xây dựng trên nền tảng sáng tạo và đổi mới có những đặc điểm hoàn toàn khác biệt:",
            items: [
              "Không chức danh, không cấp bậc, không vị trí cứng nhắc (No titles, ranks or positions)",
              "Nhân viên có thể nói 'Không' với quản lý khi có lý do chính đáng",
              "Mỗi người tự 'tạo ra' không gian làm việc của mình — tự quản, tự tổ chức",
              "Các nhóm tự hình thành tự nhiên (Organic self-formed teams) xung quanh dự án, không phải bộ phận",
              "Đổi mới: 99% về tổ chức và con người, 1% về công nghệ — ngược với quan niệm thông thường",
            ],
          },
          {
            heading: "Kinh tế Sáng tạo là gì?",
            type: "normal",
            body: "John Howkins (2001) định nghĩa Kinh tế Sáng tạo là hệ thống kinh tế nơi giá trị dựa trên các phẩm chất sáng tạo thay vì các nguồn lực truyền thống (đất đai, lao động và vốn).\n\nKhác với 'ngành công nghiệp sáng tạo' chỉ giới hạn ở một số lĩnh vực cụ thể, Kinh tế Sáng tạo mô tả sự sáng tạo lan tỏa xuyên suốt toàn bộ nền kinh tế. Kinh tế Sáng tạo xuất hiện bất cứ nơi nào sự sáng tạo cá nhân trở thành nguồn giá trị chính.",
          },
          {
            heading: "Kinh tế Sáng tạo — Con số Toàn cầu",
            type: "list",
            body: "Quy mô và tốc độ tăng trưởng của Kinh tế Sáng tạo (theo Báo cáo Liên Hợp Quốc):",
            items: [
              "Thương mại thế giới về hàng hóa và dịch vụ sáng tạo đạt 624 tỷ USD năm 2011 — tăng gấp đôi từ 2002 đến 2011",
              "Kinh tế Sáng tạo bao gồm: sản phẩm nghe nhìn, thiết kế, truyền thông mới, nghệ thuật biểu diễn, xuất bản và nghệ thuật thị giác",
              "Đây là một trong những lĩnh vực tăng trưởng nhanh nhất của kinh tế thế giới",
              "Từ 2002–2011, các nước đang phát triển đạt mức tăng trưởng xuất khẩu hàng sáng tạo trung bình 12,1%/năm",
              "Kinh tế Sáng tạo có tính lan tỏa cao về tạo thu nhập, tạo việc làm và xuất khẩu",
            ],
          },
          {
            heading: "Kết luận Báo cáo LHQ về Kinh tế Sáng tạo",
            type: "list",
            body: "Ba thông điệp cốt lõi từ Báo cáo của Liên Hợp Quốc:",
            items: [
              "Nhận ra rằng Kinh tế Sáng tạo tạo ra giá trị phi tiền tệ đóng góp đáng kể vào phát triển lấy con người làm trung tâm, toàn diện và bền vững",
              "Hiểu rằng đầu tư vào Kinh tế Sáng tạo biến văn hóa trở thành động lực và chất xúc tác cho các quá trình phát triển kinh tế, xã hội và môi trường",
              "Nhấn mạnh rằng Kinh tế Sáng tạo giúp tiết lộ cơ hội thông qua lập bản đồ các tài sản địa phương",
            ],
          },
          {
            heading: "Xã hội Sáng tạo — Nhu cầu Thay đổi Toàn diện",
            type: "list",
            body: "Xã hội Sáng tạo đòi hỏi sự chuyển đổi ở nhiều cấp độ cùng lúc:",
            items: [
              "Thể chế (Institutions) — dân chủ, thị trường, tập đoàn, đại học... cần được tái thiết kế cho kỷ nguyên mới",
              "Văn hóa (Culture) — chuyển từ giá trị xung đột sang hài hòa, từ cạnh tranh sang hợp tác",
              "Lãnh đạo (Leadership) — tư duy win-win, đề cao sáng tạo và đa văn hóa",
              "Hạ tầng (Infrastructure) — crowdsourcing, crowdfunding, mạng xã hội, cloud, blockchain làm nền tảng mới",
            ],
          },
          {
            heading: "Nghịch lý Mới vs. Cũ — Bảng so sánh",
            type: "list",
            body: "Sự dịch chuyển từ mô hình cũ sang mô hình mới (theo Maruyama 1968, vẫn còn nguyên giá trị):",
            items: [
              "Cạnh tranh → Hợp tác (Competition → Cooperation)",
              "Kỹ thuật trung tâm → Hài hòa với thiên nhiên (Technocentrism → Harmony with nature)",
              "Hiệu quả vật chất → Giá trị tinh thần (Material efficiency → Spiritual values)",
              "Phân cấp → Đội nhóm (Hierarchy → Teams)",
              "Quyền lực cho đa số → Quyền lực cho tất cả (Power to majority → Power to all)",
              "Đồng nhất → Đa dạng (Homogeneity → Pluralism)",
              "Chủ nghĩa dân tộc → Chủ nghĩa toàn cầu (Nationalism → Cosmopolitism)",
              "Thói quen → Đổi mới; Ổn định → Thay đổi (Routine → Innovation; Stability → Change)",
            ],
          },
          {
            heading: "Tài liệu Đọc Được Đề xuất",
            type: "list",
            body: "Để đào sâu hơn về Kinh tế Sáng tạo và Đổi mới:",
            items: [
              "Creative Economy — John Howkins (2001)",
              "The Entreprenaut Corporation — khám phá mô hình tổ chức doanh nhân hóa",
              "Change, Innovation and Entrepreneurship — tổng hợp ba trụ cột của tăng trưởng bền vững",
            ],
          },
        ],
      },
    },

    // ─── PHẦN II: QUẢN TRỊ SỰ THAY ĐỔI ──────────────────────────────────────────

    {
      id: "lesson-7",
      title: "Chương 1: Giới thiệu về Quản trị Sự thay đổi",
      duration: "50 phút",
      content: {
        overview:
          "Sự thay đổi không xảy ra tình cờ. Chương này giới thiệu kỷ luật có cấu trúc của Quản trị Sự thay đổi — một cách tiếp cận có nguyên tắc để hướng dẫn con người và tổ chức qua sự chuyển đổi.",
        sections: [
          {
            heading: "Bạn Sẽ Học được Gì",
            type: "normal",
            body: "Quản trị Sự thay đổi là nghệ thuật và khoa học chuẩn bị, hỗ trợ và giúp đỡ các cá nhân, nhóm và tổ chức áp dụng thành công các cách làm việc mới. Trong chương này chúng ta thiết lập vốn từ vựng nền tảng và hai khung sẽ hướng dẫn phần còn lại của môn học.",
          },
          {
            heading: "10 Giá trị Cốt lõi của Quản trị Sự thay đổi",
            type: "list",
            body: "Sự thay đổi hiệu quả được neo vào một tập hợp các giá trị chung định hình hành vi ở mọi cấp bậc của tổ chức:",
            items: [
              "1. Con người là trọng tâm — Sự thay đổi thành công hay thất bại dựa trên sự chấp nhận của con người, không phải thực thi kỹ thuật",
              "2. Minh bạch — Giao tiếp cởi mở, trung thực xây dựng niềm tin và giảm sự kháng cự",
              "3. Tham gia — Sự tham gia của các bên liên quan sớm tăng quyền sở hữu và cam kết",
              "4. Tôn trọng — Tôn trọng văn hóa và đóng góp hiện có, ngay cả khi bạn chuyển đổi chúng",
              "5. Học hỏi — Coi mỗi giai đoạn như một cơ hội để thu thập kiến thức",
              "6. Trách nhiệm giải trình — Quyền sở hữu hành động rõ ràng ngăn chặn sự mơ hồ",
              "7. Linh hoạt — Điều chỉnh kế hoạch khi thực tế diễn ra thay vì tuân thủ cứng nhắc",
              "8. Tầm nhìn — Bức tranh tương lai hấp dẫn thúc đẩy nỗ lực bền vững",
              "9. Liên kết — Lãnh đạo và quản lý phải đi cùng một hướng",
              "10. Bền vững — Thiết kế các thay đổi để tồn tại lâu dài ngoài giai đoạn dự án ban đầu",
            ],
          },
          {
            heading: "8 Bước Quản trị Sự thay đổi",
            type: "list",
            body: "Mô hình 8 bước của John Kotter vẫn là khung được áp dụng rộng rãi nhất để dẫn dắt sự thay đổi tổ chức quy mô lớn:",
            items: [
              "Bước 1: Tạo ra sự khẩn cấp — Giúp người khác thấy tại sao sự thay đổi cần thiết ngay bây giờ",
              "Bước 2: Xây dựng liên minh dẫn đạo — Tập hợp một nhóm quyền lực để dẫn dắt nỗ lực",
              "Bước 3: Hình thành tầm nhìn chiến lược — Làm rõ tương lai sẽ khác hiện tại như thế nào",
              "Bước 4: Huy động đội quân tình nguyện — Kêu gọi càng nhiều người càng tốt",
              "Bước 5: Cho phép hành động bằng cách loại bỏ rào cản — Dọn sạch các trở ngại cấu trúc và quy trình",
              "Bước 6: Tạo ra những chiến thắng ngắn hạn — Lập kế hoạch và tôn vinh những chiến thắng đầu tiên có thể nhìn thấy",
              "Bước 7: Duy trì gia tốc — Xây dựng trên đà, tiếp tục thúc đẩy",
              "Bước 8: Thể chế hóa sự thay đổi — Gắn chặt hành vi mới vào văn hóa vĩnh viễn",
            ],
          },
          {
            heading: "Mục tiêu Môn học",
            type: "normal",
            body: "Đến cuối Phần II, bạn sẽ hiểu cách thiết kế các sáng kiến thay đổi có khả năng bám lâu dài — không chỉ những sáng kiến được khởi động. Bạn sẽ có thể đánh giá sự sẵn sàng của tổ chức, giao tiếp với các bên liên quan, quản lý sự kháng cự và đo lường kết quả.",
          },
        ],
      },
    },

    {
      id: "lesson-8",
      title: "Chương 2: Quản trị Sự thay đổi là gì?",
      duration: "45 phút",
      content: {
        overview:
          "Trước khi có thể quản lý sự thay đổi, chúng ta cần định nghĩa nó một cách chính xác. Chương này xem xét cuộc khủng hoảng niềm tin lãnh đạo hiện tại và thiết lập định nghĩa nghiêm ngặt về Quản trị Sự thay đổi.",
        sections: [
          {
            heading: "Lãnh đạo vs. Quản lý",
            type: "quote",
            body: '"Lãnh đạo cần thiết để thay đổi hướng đi; Quản lý cần thiết để duy trì hướng đi."\n\n— Sự phân biệt cơ bản định hình mọi quyết định trong một sáng kiến thay đổi.',
            items: [],
          },
          {
            heading: "Giải thích Hai Vai trò",
            type: "list",
            body: "Hiểu sự phân biệt này rất quan trọng để phân công đúng người vào đúng vai trò trong bất kỳ sự chuyển đổi nào:",
            items: [
              "Lãnh đạo — Đặt ra tầm nhìn, truyền cảm hứng hành động, thách thức hiện trạng, huy động người hướng tới tương lai khác",
              "Quản lý — Tối ưu hóa các quy trình hiện có, duy trì sự ổn định hoạt động, đảm bảo kế hoạch được thực thi đáng tin cậy",
              "Sự thay đổi cần cả hai — Lãnh đạo không có quản lý tạo ra hỗn loạn; quản lý không có lãnh đạo tạo ra sự trì trệ",
            ],
          },
          {
            heading: "Cuộc khủng hoảng Niềm tin trong Lãnh đạo",
            type: "normal",
            body: "Một vấn đề dai dẳng và ngày càng trầm trọng trong các tổ chức hiện đại là sự không tin tưởng lãnh đạo. Các nghiên cứu liên tục cho thấy ít hơn một nửa nhân viên tin tưởng lãnh đạo cấp cao của họ. Điều này có hậu quả sâu sắc cho sự thay đổi: người ta không đi theo những lãnh đạo mà họ không tin. Bất kỳ sáng kiến thay đổi nào bỏ qua thực tế này đều bắt đầu với bất lợi đáng kể.",
          },
          {
            heading: "Tại sao Niềm tin bị Xói mòn",
            type: "list",
            body: "Các hành vi phổ biến phá hủy uy tín lãnh đạo trong quá trình thay đổi:",
            items: [
              "Thông báo thay đổi mà không giải thích — mọi người giả định điều tệ nhất",
              "Sự không nhất quán giữa lời nói và hành động — hứa hẹn một điều, giao một điều khác",
              "Che giấu tin xấu — tạo ra tin đồn và sợ hãi",
              "Loại trừ những người quan trọng ra khỏi các quyết định — báo hiệu rằng ý kiến của họ không quan trọng",
              "Trừng phạt sự trung thực — khiến mọi người sợ đưa ra vấn đề",
            ],
          },
          {
            heading: "Định nghĩa Chính xác",
            type: "normal",
            body: "Quản trị Sự thay đổi là tập hợp tất cả các phương pháp được sử dụng để chuẩn bị, hỗ trợ và giúp đỡ các cá nhân, nhóm và tổ chức thực hiện các chuyển đổi tổ chức thành công. Đó vừa là một kỷ luật (một phương pháp có cấu trúc) vừa là một thực hành (một tập hợp các hành vi hàng ngày mà lãnh đạo và quản lý thực hiện trong suốt một sự chuyển đổi).",
          },
          {
            heading: "Quản trị Sự thay đổi Không phải là gì",
            type: "list",
            body: "Những hiểu lầm phổ biến cần 'bỏ học':",
            items: [
              "Không phải là kế hoạch truyền thông — truyền thông là một công cụ, không phải toàn bộ kỷ luật",
              "Không phải là đào tạo — đào tạo giải quyết khoảng cách kỹ năng, quản trị thay đổi giải quyết sự sẵn sàng chấp nhận",
              "Không chỉ là quản lý dự án — PM xử lý phạm vi, thời gian, chi phí; CM xử lý con người và sự chấp nhận",
              "Không phải là điều bạn thêm vào cuối dự án — nó phải bắt đầu từ ngày đầu tiên",
            ],
          },
        ],
      },
    },

    {
      id: "lesson-9",
      title: "Chương 3: Sự thay đổi và Tư duy",
      duration: "55 phút",
      content: {
        overview:
          "Sự thay đổi sâu sắc nhất không phải là tổ chức — mà là cá nhân. Chương này xem xét cách các giá trị thúc đẩy hành vi, và cách hành vi thúc đẩy kết quả. Không có sự chuyển đổi tư duy, sự thay đổi cấu trúc hiếm khi kéo dài.",
        sections: [
          {
            heading: "Công thức Cốt lõi",
            type: "normal",
            body: "Mô hình bền vững nhất để hiểu sự thay đổi bắt đầu với một phương trình đơn giản:\n\nGIÁ TRỊ → HÀNH VI → KẾT QUẢ\n\nHầu hết các tổ chức cố gắng thay đổi kết quả trực tiếp (thông qua KPI mới, sơ đồ tổ chức mới, quy trình mới). Nhưng kết quả là những hiệu ứng hạ nguồn. Sự thay đổi lâu dài đòi hỏi làm việc thượng nguồn — bắt đầu với các giá trị, hình thành hành vi, tạo ra kết quả.",
          },
          {
            heading: "Giá trị là Gốc rễ của Sự thay đổi",
            type: "normal",
            body: "Nếu bạn muốn người ta hành xử khác đi, bạn cần thay đổi những gì họ coi trọng — hoặc giúp họ thấy cách một hành vi mới đã nhất quán với các giá trị hiện có của họ. Đây là lý do tại sao các sáng kiến thay đổi chỉ kêu gọi logic thường thất bại: chúng giải quyết tâm trí lý tính nhưng bỏ qua những động lực cảm xúc và đạo đức thực sự thúc đẩy hành động của con người.",
          },
          {
            heading: "4 Bước của Hành trình Thay đổi",
            type: "list",
            body: "Mọi sáng kiến thay đổi thành công đều trải qua bốn giai đoạn. Bỏ qua bất kỳ giai đoạn nào cũng tạo ra sự thay đổi mong manh sụp đổ dưới áp lực:",
            items: [
              "1. Xác định Nhu cầu — Tại sao chúng ta phải thay đổi? Dữ liệu, tín hiệu hoặc áp lực cạnh tranh nào làm cho hiện trạng không thể duy trì? Không có 'lý do' thuyết phục, sự thay đổi dừng lại trước khi bắt đầu",
              "2. Chuẩn bị & Lập kế hoạch — Ai bị ảnh hưởng? Cần những nguồn lực nào? Ai là người ủng hộ và ai là người hoài nghi? Xây dựng bản đồ trước khi bắt đầu hành trình",
              "3. Thực hiện — Thực thi với sự hiển thị, giao tiếp và hỗ trợ tâm lý. Đây là nơi hầu hết các kế hoạch va chạm với thực tế — hãy linh hoạt",
              "4. Duy trì — Gắn chặt sự thay đổi vào hệ thống, động cơ và văn hóa. Không có sự duy trì chủ động, các tổ chức quay trở lại các mẫu quen thuộc trong vòng 18 tháng",
            ],
          },
          {
            heading: "Sự Thay đổi Tư duy Cần thiết",
            type: "list",
            body: "Các tác nhân thay đổi thành công thể hiện một tư duy khác biệt — có thể được phát triển qua thực hành:",
            items: [
              "Từ chắc chắn đến tò mò — chấp nhận sự không chắc chắn như một tính năng, không phải lỗi",
              "Từ bản ngã đến sứ mệnh — sự thay đổi quan trọng hơn việc đúng",
              "Từ sợ hãi đến thử nghiệm — coi thất bại là dữ liệu, không phải thất bại",
              "Từ kiểm soát đến ảnh hưởng — trong các tổ chức phức tạp, bạn hiếm khi kiểm soát kết quả nhưng luôn ảnh hưởng đến chúng",
            ],
          },
          {
            heading: "Bài tập Phản ánh",
            type: "normal",
            body: "Hãy nghĩ về một sự thay đổi bạn cá nhân đã kháng cự. Giá trị nào của bạn đã bị đe dọa? Bây giờ hãy xem xét: có cách nào để đóng khung sự thay đổi mà sẽ tôn trọng giá trị đó không? Đây là quan điểm của một người quản lý sự thay đổi — tìm sự liên kết giữa những gì phải thay đổi và những gì mọi người trân trọng.",
          },
        ],
      },
    },

    {
      id: "lesson-10",
      title: "Chương 4: Văn hóa Cộng tác",
      duration: "50 phút",
      content: {
        overview:
          "Không có sự thay đổi tổ chức đáng kể nào thành công nếu không có văn hóa cho phép mọi người làm việc cùng nhau xuyên ranh giới. Chương này xem xét văn hóa cộng tác trông như thế nào — và mô hình thực tế để xây dựng nó.",
        sections: [
          {
            heading: "Tại sao Cộng tác Không thể Thiếu",
            type: "normal",
            body: "Sự thay đổi luôn làm gián đoạn các cấu trúc quyền lực, quy trình làm việc và danh tính hiện có. Không có văn hóa hỗ trợ giải quyết vấn đề cộng tác, mỗi sự gián đoạn trở thành xung đột. Với nó, sự gián đoạn trở thành cơ hội cho đổi mới chung. Cộng tác không phải là đặc điểm tính cách — đó là cơ sở hạ tầng văn hóa.",
          },
          {
            heading: "Các Yếu tố của Văn hóa Cộng tác",
            type: "list",
            body: "Các tổ chức có văn hóa cộng tác mạnh chia sẻ các tính năng cấu trúc và hành vi chung:",
            items: [
              "An toàn tâm lý — Mọi người lên tiếng mà không sợ bị chế nhạo hoặc trừng phạt",
              "Ngôn ngữ chung — Các nhóm có khung và thuật ngữ chung để thảo luận vấn đề",
              "Mục tiêu rõ ràng và được chia sẻ — Các đóng góp cá nhân được kết nối rõ ràng với kết quả tập thể",
              "Mối quan hệ liên chức năng — Mọi người biết và tin tưởng đồng nghiệp ngoài nhóm trực tiếp của họ",
              "Chuẩn mực xung đột — Bất đồng được kỳ vọng và quản lý mang tính xây dựng, không bị dập tắt",
              "Hệ thống ghi nhận — Sự cộng tác được khen thưởng, không chỉ là những anh hùng cá nhân",
            ],
          },
          {
            heading: "Mô hình 51:49 — Nhóm trên Cá nhân",
            type: "normal",
            body: "Một trong những khung thực tế nhất để xây dựng sự đồng thuận cộng tác là Mô hình 51:49. Nguyên tắc đơn giản nhưng đòi hỏi cao: khi cần đưa ra quyết định, đặt lợi ích tập thể của nhóm 51% lên trên lợi ích cá nhân 49% của bạn. Bạn không xóa bỏ quan điểm cá nhân — bạn phụ thuộc nó khi lợi ích chung đòi hỏi.",
          },
          {
            heading: "Cách 51:49 Hoạt động trong Thực tế",
            type: "list",
            body: "Mô hình này tạo ra các hành vi cụ thể, quan sát được trong các nhóm sẵn sàng thay đổi:",
            items: [
              "Mọi người hỗ trợ các quyết định họ cá nhân không đồng ý, sau khi nhóm đã quyết định",
              "Lãnh đạo công khai làm gương hy sinh — từ bỏ sở thích cá nhân cho sự gắn kết nhóm",
              "Quan điểm thiểu số được nghe và ghi lại trước khi các quyết định được đóng lại",
              "Công lao được chia sẻ rộng rãi, không được nhận bởi giọng nói to nhất",
              "Trách nhiệm là tập thể — nhóm sở hữu cả thành công và thất bại",
            ],
          },
          {
            heading: "Xây dựng Sự đồng thuận trong Thực tế",
            type: "normal",
            body: "Đồng thuận không có nghĩa là nhất trí — có nghĩa là mọi người có thể sống với quyết định và cam kết làm cho nó hoạt động. Các nhà quản lý thay đổi hiệu quả biết cách điều hành các phiên xây dựng đồng thuận có cấu trúc: đưa ra mối lo ngại, kiểm tra các giả định, tìm vùng thỏa thuận có thể và kết thúc với cam kết rõ ràng. Kỹ năng này có thể học được, và đó là một trong những năng lực đòn bẩy cao nhất mà một lãnh đạo thay đổi có thể phát triển.",
          },
        ],
      },
    },

    {
      id: "lesson-11",
      title: "Chương 5: Mẹo và Thủ thuật — 7 Yếu tố Thiết yếu",
      duration: "60 phút",
      content: {
        overview:
          "Các khung có cấu trúc cần thiết nhưng chưa đủ. Chương này cung cấp bảy yếu tố thiết yếu thực tế — những bài học khó khăn từ các chuyên gia thay đổi — phân biệt các sáng kiến thành công với những sáng kiến đình trệ.",
        sections: [
          {
            heading: "Yếu tố 1: Xác định Mục tiêu Các bên Liên quan & Xây dựng Luận điểm Kinh doanh",
            type: "normal",
            body: "Trước khi thông báo bất kỳ sự thay đổi nào, hãy lập bản đồ các bên liên quan. Ai được lợi? Ai mất? Ai phải được thuyết phục? Ai có quyền phủ quyết? Sau đó xây dựng luận điểm kinh doanh nghiêm ngặt: sự thay đổi này giải quyết vấn đề gì, chi phí không thay đổi là gì, và thành công trông như thế nào theo các thuật ngữ có thể đo lường được? Một sáng kiến thay đổi không có luận điểm kinh doanh thuyết phục là một sáng kiến sẽ thua trong cuộc tranh luận về ngân sách.",
          },
          {
            heading: "Yếu tố 2: Theo dõi Rủi ro, Chi phí và ROI",
            type: "normal",
            body: "Quản trị Sự thay đổi phải được coi là đầu tư, không phải chi phí. Theo dõi liên tục ba điều: rủi ro (điều gì có thể cản trở chúng ta và khả năng xảy ra mỗi điều?), chi phí (chi phí trực tiếp cộng với mất mát năng suất trong quá trình chuyển đổi) và ROI (giá trị được tạo ra được định lượng chia cho tổng đầu tư). Các tổ chức quản lý sự thay đổi như một kỷ luật tài chính kiếm được quyền tài trợ cho các sáng kiến tương lai.",
          },
          {
            heading: "Yếu tố 3: Giao tiếp Minh bạch — Tại sao, Lợi ích của tôi là gì, Chi phí là bao nhiêu?",
            type: "list",
            body: "Giao tiếp không phải là nhắn tin — đó là đối thoại. Giao tiếp thay đổi hiệu quả trả lời ba câu hỏi mà mỗi người bị ảnh hưởng đang đặt ra:",
            items: [
              "Tại sao chúng ta thay đổi? — Kết nối sự thay đổi với một vấn đề thực tế, khẩn cấp, có thể nhìn thấy",
              "Lợi ích của tôi là gì? — Thành thật về cả lợi ích và khó khăn",
              "Điều này tốn bao nhiêu? — Sự minh bạch về chi phí xây dựng uy tín; che giấu nó phá hủy niềm tin",
            ],
          },
          {
            heading: "Yếu tố 4: Xây dựng Kế hoạch Nâng cấp Kỹ năng",
            type: "normal",
            body: "Sự thay đổi thường đòi hỏi năng lực mới. Xác định khoảng cách kỹ năng giữa tổ chức của bạn hiện tại và nơi cần phải đến. Sau đó xây dựng chương trình đào tạo và phát triển — không phải sự kiện một lần, mà là chương trình bền vững hỗ trợ mọi người qua đường cong học tập. Mục tiêu là năng lực và sự tự tin, không chỉ là tuân thủ.",
          },
          {
            heading: "Yếu tố 5: Quản lý Sự Kháng cự",
            type: "normal",
            body: "Sự kháng cự không phải là vô lý — đó là thông tin. Mọi người kháng cự sự thay đổi vì họ đang bảo vệ điều gì đó: an toàn công việc, danh tính chuyên môn, các mối quan hệ, thói quen. Các nhà quản lý thay đổi hiệu quả lắng nghe sự kháng cự mà không bảo vệ chống lại nó. Họ hỏi: 'Điều gì cần đúng để bạn ủng hộ điều này?' Sự kháng cự được quản lý tốt thường tạo ra những ý tưởng tốt nhất của sáng kiến thay đổi.",
          },
          {
            heading: "Yếu tố 6: Cung cấp Huấn luyện Cá nhân để Giảm Sợ hãi",
            type: "normal",
            body: "Giao tiếp nhóm đơn thuần là không đủ. Nhiều người cần các cuộc trò chuyện một-một để xử lý cách sự thay đổi sẽ ảnh hưởng đến họ cá nhân. Cung cấp quyền truy cập vào huấn luyện — từ các nhà quản lý, HR hoặc huấn luyện viên bên ngoài — giảm đáng kể nỗi sợ hãi và sự không chắc chắn làm chậm sự chấp nhận. Điều này đặc biệt đúng với những người đóng góp cấp cao có danh tính gắn chặt với cách làm hiện tại.",
          },
          {
            heading: "Yếu tố 7: Theo dõi Tiến độ và Tinh chỉnh Liên tục",
            type: "list",
            body: "Các sáng kiến thay đổi không được khởi động rồi quản lý — chúng được chẩn đoán và điều chỉnh liên tục. Theo dõi các chỉ số dẫn đầu về sự chấp nhận, không chỉ các chỉ số trễ về kết quả:",
            items: [
              "Dẫn đầu: tỷ lệ tham gia, điểm tâm lý, số lượng câu hỏi được đặt ra, tần suất sử dụng công cụ/quy trình mới",
              "Trễ: các chỉ số năng suất, tỷ lệ lỗi, tỷ lệ giữ chân, kết quả tài chính",
              "Tinh chỉnh dựa trên dữ liệu — nếu sự chấp nhận chậm trong một nhóm, tìm hiểu tại sao trước khi giả định không tuân thủ",
            ],
          },
        ],
      },
    },

    {
      id: "lesson-12",
      title: "Chương 6: Chuẩn bị Dự án Quản trị Sự thay đổi",
      duration: "40 phút",
      content: {
        overview:
          "Chương này kết nối lý thuyết và thực tiễn. Nó chuẩn bị học viên cho thành phần dự án thực hành — một sáng kiến quản lý thay đổi thực tế mà họ sẽ thiết kế và trình bày theo nhóm.",
        sections: [
          {
            heading: "Tổng quan Dự án",
            type: "normal",
            body: "Dự án kết thúc khóa học này yêu cầu bạn thiết kế một sáng kiến quản lý thay đổi hoàn chỉnh cho một kịch bản tổ chức thực tế hoặc thực tế. Bạn sẽ áp dụng mọi khung và công cụ được đề cập trong khóa học này — từ lập bản đồ các bên liên quan và phát triển luận điểm kinh doanh, đến lập kế hoạch giao tiếp và quản lý sự kháng cự — để tạo ra một sản phẩm có thể hoạt động trong một tổ chức thực tế.",
          },
          {
            heading: "Hướng dẫn Thành lập Nhóm",
            type: "list",
            body: "Các dự án quản lý thay đổi mạnh phản ánh sự đa dạng của các nhóm thay đổi thực tế:",
            items: [
              "Nhóm 4–5 học viên — đủ lớn cho sự phức tạp, đủ nhỏ cho trách nhiệm",
              "Phân công vai trò trước khi bắt đầu: Trưởng Dự án, Trưởng Truyền thông, Quản lý Rủi ro, Trưởng Nghiên cứu, Trưởng Thuyết trình",
              "Luân phiên vai trò Trưởng Dự án trong các cuộc họp nhóm — mọi người thực hành dẫn dắt",
              "Ghi lại quá trình của bạn, không chỉ kết luận của bạn — giảng viên sẽ đánh giá cách bạn đưa ra quyết định",
            ],
          },
          {
            heading: "Sản phẩm Bàn giao Dự án",
            type: "list",
            body: "Bài nộp cuối cùng của bạn sẽ bao gồm bốn thành phần:",
            items: [
              "1. Phân tích Tình huống — Tổ chức nào, vấn đề gì, tại sao sự thay đổi cần thiết ngay bây giờ",
              "2. Bản đồ Các bên Liên quan — Ai bị ảnh hưởng, lợi ích của họ, ảnh hưởng của họ và chiến lược tham gia của bạn",
              "3. Kế hoạch Quản lý Thay đổi — Sử dụng mô hình 8 bước, với lịch trình, kế hoạch truyền thông, kế hoạch đào tạo và chiến lược kháng cự",
              "4. Khung Đo lường — Cách bạn biết sự thay đổi đã thành công; các chỉ số dẫn đầu và trễ",
            ],
          },
          {
            heading: "Sắp ra mắt",
            type: "normal",
            body: "Hướng dẫn dự án chi tiết, rubric đánh giá và ví dụ bài nộp sẽ được đăng tại đây sớm. Học viên nên bắt đầu thành lập nhóm và thảo luận về các kịch bản tổ chức tiềm năng. Các nhóm mạnh chọn kịch bản của họ sớm — đừng chờ hướng dẫn chi tiết trước khi có các cuộc trò chuyện ban đầu.",
          },
          {
            heading: "Chuẩn bị Được Đề xuất",
            type: "list",
            body: "Trước khi bản tóm tắt dự án được phát hành, hãy chuẩn bị bằng cách:",
            items: [
              "Xem lại tất cả ghi chú chương và xác định các khung liên quan nhất đến kịch bản của bạn",
              "Đọc ít nhất một chương của 'Leading Change' bởi John P. Kotter",
              "Xác định hai hoặc ba trường hợp thay đổi tổ chức thực tế mà bạn có thể phân tích",
              "Có cuộc họp nhóm đầu tiên để thống nhất về phong cách làm việc và điểm mạnh",
            ],
          },
        ],
      },
    },

    {
      id: "lesson-13",
      title: "Chương 7: Tổng kết & Bài tập Cuối khóa",
      duration: "45 phút",
      content: {
        overview:
          "Khóa học kết thúc với sự tổng hợp các khái niệm chính, các đề xuất đọc thiết yếu và các bài tập cuối khóa sẽ xác định điểm số của bạn.",
        sections: [
          {
            heading: "Tổng kết Khóa học",
            type: "list",
            body: "Qua 13 bài học, chúng ta đã đề cập đến một khung hoàn chỉnh để hiểu và dẫn dắt đổi mới và thay đổi:",
            items: [
              "Đổi mới là một kỷ luật có quản lý — không phải cảm hứng ngẫu nhiên mà là sáng tạo có hệ thống",
              "Đổi mới gián đoạn và duy trì đòi hỏi các chiến lược hoàn toàn khác nhau",
              "Tư duy sáng tạo có thể học được — cả chế độ phân kỳ và hội tụ đều thiết yếu",
              "Rào cản đối với sáng tạo chủ yếu là văn hóa và cấu trúc — chúng có thể được loại bỏ",
              "Quản lý thay đổi bắt đầu bằng niềm tin và giá trị — không phải quy trình và hệ thống",
              "Văn hóa cộng tác là nền tảng làm cho sự thay đổi bền lâu",
              "Mô hình 8 bước cung cấp con đường đáng tin cậy qua các sự chuyển đổi phức tạp",
              "Sự kháng cự là thông tin — hãy lắng nghe nó trước khi bác bỏ",
              "Đo lường đóng vòng lặp — những gì được theo dõi thì được cải thiện",
            ],
          },
          {
            heading: "Đọc Thiết yếu",
            type: "list",
            body: "Giảng viên giới thiệu các tài nguyên sau để nghiên cứu sâu hơn:",
            items: [
              "Leading Change — John P. Kotter (văn bản định nghĩa về mô hình 8 bước)",
              "Change or Die — Alan Deutschman (tại sao mọi người kháng cự sự thay đổi ngay cả khi cuộc sống của họ phụ thuộc vào nó — và cách vượt qua)",
              "The Innovator's Dilemma — Clayton Christensen (văn bản nền tảng về đổi mới gián đoạn)",
              "Blog của Giảng viên — Được cập nhật thường xuyên với các trường hợp hiện tại, khung và bình luận về tin tức đổi mới",
            ],
          },
          {
            heading: "Bài tập Cuối khóa 1: Bài luận Cá nhân",
            type: "normal",
            body: "Viết một bài luận 1.000–1.500 từ trả lời câu hỏi sau:\n\n\"Triết lý quản lý sự thay đổi cá nhân của bạn là gì — và tại sao người khác muốn bạn dẫn dắt một sáng kiến thay đổi?\"\n\nĐây không phải là bài tập tóm tắt học thuật. Đó là một tuyên bố cá nhân thực sự. Chúng tôi muốn biết bạn suy nghĩ như thế nào, bạn tin gì, và bạn sẽ xuất hiện như thế nào với tư cách là một lãnh đạo thay đổi. Tham chiếu các khái niệm khóa học, nhưng hãy gắn chúng với kinh nghiệm và giá trị của chính bạn.",
          },
          {
            heading: "Bài tập Cuối khóa 2: Nghiên cứu Trường hợp",
            type: "list",
            body: "Tìm và phân tích một sự thay đổi tổ chức lớn trong thực tế. Các lựa chọn tốt bao gồm:",
            items: [
              "Sự chuyển đổi của Apple dưới Steve Jobs (1997–2001) — từ gần phá sản đến biểu tượng văn hóa",
              "Sự chuyển hướng của Netflix từ cho thuê DVD sang phát trực tuyến sang sản xuất nội dung",
              "Sự chuyển đổi văn hóa của Microsoft dưới Satya Nadella (2014–nay)",
              "Việc Toyota áp dụng sản xuất Lean",
              "Bất kỳ sáng kiến thay đổi nào bạn đã chứng kiến cá nhân trong một tổ chức mà bạn biết rõ",
            ],
          },
          {
            heading: "Yêu cầu Nghiên cứu Trường hợp",
            type: "list",
            body: "Nghiên cứu trường hợp của bạn (1.200–2.000 từ) phải giải quyết:",
            items: [
              "Điều gì đã kích hoạt nhu cầu thay đổi?",
              "Làm thế nào để lãnh đạo tạo ra sự khẩn cấp và tầm nhìn?",
              "Sự kháng cự nào đã gặp phải, và nó được quản lý như thế nào?",
              "Điều gì đã làm cho sự thay đổi thành công hay thất bại?",
              "Bạn sẽ làm gì khác đi, và tại sao?",
            ],
          },
          {
            heading: "Hạn Nộp bài",
            type: "normal",
            body: "Tất cả các bài nộp cuối khóa phải được nộp trước ngày 15/05/2026 qua cổng SSBM. Học viên nộp bài trước hạn chót sẽ nhận được phản hồi và có cơ hội sửa đổi lần cuối. Không chấp nhận gia hạn trừ khi có hoàn cảnh ngoại lệ được ghi chép.",
          },
        ],
      },
    },
  ],
};
