import { useState, useEffect } from "react";
import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Navbar from "@/components/Navbar";
import CoursePage from "@/pages/CoursePage";
import ComingSoon from "@/components/ComingSoon";
import { subjects, type Subject } from "@/data/courseData";

const queryClient = new QueryClient();

function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-foreground">404 — Page Not Found</h1>
        <p className="text-muted-foreground mt-2">This page does not exist.</p>
      </div>
    </div>
  );
}

function AppShell() {
  const [currentSubject, setCurrentSubject] = useState<Subject>(subjects[0]);
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [darkMode]);

  return (
    <div className="flex flex-col h-screen overflow-hidden bg-background" data-testid="app-shell">
      <Navbar
        currentSubject={currentSubject}
        onSubjectChange={setCurrentSubject}
        darkMode={darkMode}
        onToggleDark={() => setDarkMode((v) => !v)}
      />
      <main className="flex-1 overflow-hidden" data-testid="main-content">
        {currentSubject.available ? (
          <CoursePage />
        ) : (
          <ComingSoon subject={currentSubject} />
        )}
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Switch>
            <Route path="/" component={AppShell} />
            <Route component={NotFound} />
          </Switch>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
