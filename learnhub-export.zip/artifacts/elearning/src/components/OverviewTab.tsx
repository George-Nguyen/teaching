import { Target, BookOpen, Calendar, Award, ExternalLink, Linkedin, Facebook } from "lucide-react";
import type { Course } from "@/data/courseData";

interface OverviewTabProps {
  course: Course;
}

export default function OverviewTab({ course }: OverviewTabProps) {
  return (
    <div className="p-6 lg:p-8" data-testid="overview-tab">
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 max-w-7xl mx-auto">

        {/* LEFT COLUMN — main content */}
        <div className="xl:col-span-2 space-y-5">

          {/* Course Hero */}
          <div className="bg-gradient-to-br from-primary/10 to-accent rounded-2xl p-6 border border-primary/20">
            <div className="text-xs font-semibold text-primary uppercase tracking-wider mb-2">{course.subtitle}</div>
            <h1 className="text-2xl lg:text-3xl font-bold text-foreground font-serif leading-tight" data-testid="course-hero-title">
              {course.title}
            </h1>
            <p className="mt-3 text-muted-foreground leading-relaxed">{course.description}</p>
          </div>

          {/* Objectives */}
          <div className="bg-card border border-border rounded-xl p-6">
            <div className="flex items-center gap-2 mb-3">
              <Target className="w-4 h-4 text-primary shrink-0" />
              <h2 className="text-base font-semibold text-foreground">Mục tiêu Môn học</h2>
            </div>
            <p className="text-muted-foreground leading-relaxed text-sm" data-testid="course-objectives">
              {course.objectives}
            </p>
          </div>

          {/* Instructor */}
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="px-6 pt-6 pb-4 flex items-center gap-2 border-b border-border">
              <h2 className="text-base font-semibold text-foreground">Giảng viên</h2>
            </div>
            <div className="p-6" data-testid="instructor-card">
              <div className="flex items-start gap-5">
                {/* Photo */}
                <img
                  src="/george-nguyen.jpg"
                  alt="George Nguyen"
                  className="w-20 h-20 rounded-2xl object-cover object-top shrink-0 border-2 border-border shadow"
                />
                <div className="flex-1 min-w-0">
                  <div className="text-base font-bold text-foreground">{course.instructor}</div>
                  <div className="text-xs text-primary mt-0.5 font-medium">{course.instructorTitle}</div>
                  <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
                    George là một nhân vật truyền cảm hứng trong thế giới khởi nghiệp, chuyên về các startup Công nghệ và Blockchain. Là một doanh nhân nối tiếp, George đã thành công thành lập một Tech Lab và một công ty outsourcing năng động. Với con mắt nhạy bén nhìn ra cơ hội, ông tích cực đầu tư vào nhiều nhà cung cấp dịch vụ trong hệ sinh thái startup sôi động.
                  </p>
                  {/* Stats */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-4">
                    {[
                      { num: "21", label: "Năm kinh nghiệm ngành" },
                      { num: "10", label: "Năm doanh nhân Blockchain + AI" },
                      { num: "7", label: "Năm giảng dạy tại RMIT" },
                      { num: "2", label: "Labs đồng sáng lập" },
                      { num: "4", label: "Hội đồng cố vấn (RMIT, UEF, Hutech, SSBM)" },
                      { num: "5M$", label: "Gây quỹ thành công cho 2 startup" },
                    ].map(({ num, label }) => (
                      <div key={label} className="bg-muted/50 rounded-xl p-3 text-center">
                        <div className="text-lg font-bold text-primary">{num}</div>
                        <div className="text-[11px] text-muted-foreground leading-tight mt-0.5">{label}</div>
                      </div>
                    ))}
                  </div>
                  {/* Social links */}
                  <div className="flex gap-3 mt-4">
                    <a
                      href="https://www.linkedin.com/in/georgenguyen79/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-xs text-blue-600 dark:text-blue-400 hover:underline"
                    >
                      <Linkedin className="w-3.5 h-3.5" />
                      LinkedIn
                    </a>
                    <a
                      href="https://www.facebook.com/george.nguyen79"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-xs text-blue-600 dark:text-blue-400 hover:underline"
                    >
                      <Facebook className="w-3.5 h-3.5" />
                      Facebook
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* What You'll Learn */}
          <div className="bg-card border border-border rounded-xl p-6">
            <h2 className="text-base font-semibold text-foreground mb-4">Bạn Sẽ Học được Gì</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                "Nguyên lý đổi mới gián đoạn vs. duy trì",
                "Tư duy sáng tạo sử dụng phương pháp hội tụ & phân kỳ",
                "10 Giá trị Cốt lõi và 8 Bước Quản trị Sự thay đổi",
                "Cách xây dựng văn hóa cộng tác, sẵn sàng thay đổi",
                "Quản lý sự kháng cự, các bên liên quan và rủi ro",
                "Công cụ được sử dụng bởi Google, Netflix, Disney và Sony",
              ].map((item, i) => (
                <div key={i} className="flex items-start gap-2.5">
                  <div className="w-5 h-5 rounded-full bg-primary/15 flex items-center justify-center shrink-0 mt-0.5">
                    <span className="text-[10px] font-bold text-primary">{i + 1}</span>
                  </div>
                  <span className="text-sm text-muted-foreground leading-snug">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN — sidebar widgets */}
        <div className="space-y-5">

          {/* Quick Stats */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-sm font-semibold text-foreground mb-4">Thông tin Môn học</h3>
            <div className="space-y-3">
              {[
                { icon: BookOpen, label: "Bài học", value: `${course.lessonsCount} bài` },
                { icon: Calendar, label: "Thời lượng", value: course.duration },
                { icon: Award, label: "Tín chỉ", value: "3 tín chỉ học thuật" },
                { icon: Target, label: "Cấp độ", value: "Nâng cao" },
              ].map(({ icon: Icon, label, value }) => (
                <div key={label} className="flex items-center gap-3" data-testid={`stat-${label.toLowerCase()}`}>
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <Icon className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground">{label}</div>
                    <div className="text-sm font-medium text-foreground">{value}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Course Structure */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-sm font-semibold text-foreground mb-3">Cấu trúc Môn học</h3>
            <div className="space-y-2">
              {[
                { part: "Phần I", title: "Quản lý Đổi mới & Sáng tạo", lessons: "Bài 1–8" },
                { part: "Phần II", title: "Quản trị Sự thay đổi", lessons: "Chương 1–7" },
              ].map(({ part, title, lessons }) => (
                <div key={part} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                  <span className="text-xs font-bold text-primary bg-primary/10 px-2 py-1 rounded shrink-0">{part}</span>
                  <div>
                    <div className="text-sm font-medium text-foreground">{title}</div>
                    <div className="text-xs text-muted-foreground">{lessons}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Grading Summary */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-sm font-semibold text-foreground mb-3">Thang điểm Tóm tắt</h3>
            <div className="space-y-1.5">
              {[
                { grade: "A", range: "90–100", color: "bg-emerald-500" },
                { grade: "B", range: "80–89", color: "bg-blue-500" },
                { grade: "C", range: "70–79", color: "bg-yellow-500" },
                { grade: "D", range: "60–69", color: "bg-orange-500" },
                { grade: "F", range: "< 60", color: "bg-red-500" },
              ].map(({ grade, range, color }) => (
                <div key={grade} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div className={`w-5 h-5 rounded ${color} flex items-center justify-center`}>
                      <span className="text-white font-bold text-[10px]">{grade}</span>
                    </div>
                    <span className="text-foreground">Loại {grade}</span>
                  </div>
                  <span className="text-muted-foreground font-mono text-xs">{range}</span>
                </div>
              ))}
            </div>
            <div className="mt-3 pt-3 border-t border-border">
              <p className="text-xs text-muted-foreground">Điểm qua môn tối thiểu: <span className="font-semibold text-foreground">61 điểm</span></p>
            </div>
          </div>

          {/* Resources */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-sm font-semibold text-foreground mb-3">Tài liệu Đọc Chính</h3>
            <div className="space-y-2">
              {[
                "Leading Change — John P. Kotter",
                "Change or Die — Alan Deutschman",
                "The Innovator's Dilemma — Clayton Christensen",
              ].map((book) => (
                <div key={book} className="flex items-start gap-2">
                  <ExternalLink className="w-3.5 h-3.5 text-primary shrink-0 mt-0.5" />
                  <span className="text-xs text-muted-foreground leading-snug">{book}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
