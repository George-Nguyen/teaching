import { useState, useEffect, useRef } from "react";
import { ChevronRight, CheckCircle, BookOpen, Clock, List } from "lucide-react";
import type { Lesson } from "@/data/courseData";

interface LessonContentProps {
  lesson: Lesson;
  lessonIndex: number;
  totalLessons: number;
  isCompleted: boolean;
  onMarkComplete: (lessonId: string) => void;
  onNext: () => void;
  onPrev: () => void;
}

export default function LessonContent({
  lesson,
  lessonIndex,
  totalLessons,
  isCompleted,
  onMarkComplete,
  onNext,
  onPrev,
}: LessonContentProps) {
  const [expanded, setExpanded] = useState<Set<number>>(new Set(lesson.content.sections.map((_, i) => i)));
  const [activeSection, setActiveSection] = useState(0);
  const sectionRefs = useRef<(HTMLDivElement | null)[]>([]);

  const toggleSection = (idx: number) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(idx)) next.delete(idx);
      else next.add(idx);
      return next;
    });
  };

  const expandAll = () => setExpanded(new Set(lesson.content.sections.map((_, i) => i)));
  const collapseAll = () => setExpanded(new Set());

  useEffect(() => {
    setExpanded(new Set(lesson.content.sections.map((_, i) => i)));
    setActiveSection(0);
  }, [lesson.id, lesson.content.sections.length]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const idx = sectionRefs.current.indexOf(entry.target as HTMLDivElement);
            if (idx !== -1) setActiveSection(idx);
          }
        });
      },
      { threshold: 0.3 }
    );
    sectionRefs.current.forEach((ref) => ref && observer.observe(ref));
    return () => observer.disconnect();
  }, [lesson.id]);

  const scrollToSection = (idx: number) => {
    sectionRefs.current[idx]?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="flex-1 overflow-y-auto" data-testid="lesson-content">
      {/* Lesson Header */}
      <div className="px-6 lg:px-10 pt-6 pb-5 border-b border-border bg-card">
        <div className="flex items-center justify-between gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 text-xs text-muted-foreground mb-2">
              <BookOpen className="w-3.5 h-3.5 shrink-0" />
              <span>Bài {lessonIndex + 1} / {totalLessons}</span>
              <span className="mx-1">·</span>
              <Clock className="w-3.5 h-3.5 shrink-0" />
              <span>{lesson.duration}</span>
            </div>
            <h1 className="text-xl lg:text-2xl font-bold text-foreground font-serif" data-testid="lesson-title">
              {lesson.title}
            </h1>
            <p className="mt-2 text-sm text-muted-foreground leading-relaxed" data-testid="lesson-overview">
              {lesson.content.overview}
            </p>
          </div>
          {isCompleted && (
            <div className="shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-700 dark:text-emerald-400 rounded-full text-xs font-medium border border-emerald-200 dark:border-emerald-800" data-testid="completed-badge">
              <CheckCircle className="w-3.5 h-3.5" />
              Hoàn thành
            </div>
          )}
        </div>

        {/* Expand / Collapse */}
        <div className="flex items-center gap-2 mt-3">
          <button onClick={expandAll} className="text-xs text-primary hover:underline">Mở rộng tất cả</button>
          <span className="text-muted-foreground/50">·</span>
          <button onClick={collapseAll} className="text-xs text-muted-foreground hover:text-foreground">Thu gọn tất cả</button>
        </div>
      </div>

      {/* Content grid: sections + sticky TOC */}
      <div className="flex gap-0 relative">

        {/* Main sections */}
        <div className="flex-1 min-w-0 px-6 lg:px-10 py-6 space-y-3">
          {lesson.content.sections.map((section, idx) => {
            const isOpen = expanded.has(idx);
            return (
              <div
                key={idx}
                ref={(el) => { sectionRefs.current[idx] = el; }}
                className="bg-card rounded-xl border border-border overflow-hidden"
                data-testid={`section-${idx}`}
              >
                <button
                  onClick={() => toggleSection(idx)}
                  className="w-full flex items-center justify-between px-5 py-4 hover:bg-muted/40 transition-colors"
                  data-testid={`section-toggle-${idx}`}
                >
                  <h2 className="text-sm lg:text-base font-semibold text-foreground text-left">{section.heading}</h2>
                  <ChevronRight
                    className={`w-4 h-4 text-muted-foreground shrink-0 transition-transform ${isOpen ? "rotate-90" : ""}`}
                  />
                </button>

                {isOpen && (
                  <div className="px-5 pb-5">
                    <div className="prose-elearning">
                      {section.type === "quote" ? (
                        <div className="space-y-3">
                          {section.body.split("\n\n").map((q, qi) => (
                            <blockquote key={qi}>{q}</blockquote>
                          ))}
                        </div>
                      ) : section.type === "list" ? (
                        <div>
                          {section.body && <p>{section.body}</p>}
                          <ul>
                            {section.items?.map((item, ii) => (
                              <li key={ii}>{item}</li>
                            ))}
                          </ul>
                        </div>
                      ) : (
                        <p>{section.body}</p>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {/* Bottom navigation */}
          <div className="flex items-center justify-between pt-4 pb-6">
            <button
              onClick={onPrev}
              disabled={lessonIndex === 0}
              className="px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg border border-border transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              data-testid="prev-lesson-btn"
            >
              ← Bài trước
            </button>

            <div className="flex items-center gap-3">
              {!isCompleted && (
                <button
                  onClick={() => onMarkComplete(lesson.id)}
                  className="px-4 py-2 text-sm font-medium bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition-colors"
                  data-testid="mark-complete-btn"
                >
                  Đánh dấu Hoàn thành
                </button>
              )}
              {lessonIndex < totalLessons - 1 && (
                <button
                  onClick={onNext}
                  className="px-4 py-2 text-sm font-medium bg-primary hover:bg-primary/90 text-primary-foreground rounded-lg transition-colors"
                  data-testid="next-lesson-btn"
                >
                  Bài tiếp →
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Sticky TOC — only on large screens */}
        <div className="hidden xl:block w-60 shrink-0">
          <div className="sticky top-4 pt-6 pr-6">
            <div className="bg-card border border-border rounded-xl p-4">
              <div className="flex items-center gap-1.5 mb-3">
                <List className="w-3.5 h-3.5 text-muted-foreground" />
                <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Nội dung Bài học</span>
              </div>
              <div className="space-y-1">
                {lesson.content.sections.map((section, idx) => (
                  <button
                    key={idx}
                    onClick={() => scrollToSection(idx)}
                    className={`w-full text-left text-xs px-2 py-1.5 rounded-md transition-colors leading-snug
                      ${activeSection === idx
                        ? "bg-primary/10 text-primary font-medium"
                        : "text-muted-foreground hover:text-foreground hover:bg-muted"
                      }`}
                    data-testid={`toc-item-${idx}`}
                  >
                    {section.heading}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
