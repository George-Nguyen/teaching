import { useState } from "react";
import { CheckCircle2, AlertCircle, Download, FileText, Lightbulb, RefreshCw, Star, Clock, MapPin } from "lucide-react";

type OptionId = "innovation" | "change";

export default function FinalProjectTab() {
  const [selectedOption, setSelectedOption] = useState<OptionId | null>(null);
  const [activeRubric, setActiveRubric] = useState<OptionId>("innovation");

  return (
    <div className="flex-1 overflow-y-auto" data-testid="final-project-tab">

      {/* ── SECTION 1: HERO ── */}
      <div className="relative bg-gradient-to-br from-sidebar via-sidebar to-primary/80 text-white px-6 lg:px-12 py-14 overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "radial-gradient(circle at 70% 50%, white 1px, transparent 1px)", backgroundSize: "32px 32px" }} />
        <div className="relative max-w-4xl">
          <div className="inline-flex items-center gap-2 bg-white/10 border border-white/20 rounded-full px-3 py-1 text-xs font-semibold mb-5 tracking-wider uppercase">
            IM401 · Final Assessment
          </div>
          <h1 className="text-3xl lg:text-4xl font-bold font-serif leading-tight" data-testid="project-hero-title">
            FINAL MBA PROJECT
            <br />
            <span className="text-primary/80 dark:text-blue-300">Innovation &amp; Change Management</span>
          </h1>
          <p className="mt-3 text-white/70 text-lg font-light italic">
            "Transforming Mindsets — Shaping the Future"
          </p>
          <p className="mt-2 text-sm text-white/60">Chuyển hóa Tư duy — Định hình Tương lai</p>
          <div className="flex flex-wrap gap-3 mt-8">
            <a
              href="#guidelines"
              className="inline-flex items-center gap-2 bg-white text-sidebar font-semibold px-5 py-2.5 rounded-lg text-sm hover:bg-white/90 transition-colors"
              data-testid="cta-guidelines"
            >
              <FileText className="w-4 h-4" />
              Xem Hướng dẫn Chi tiết
            </a>
            <button
              className="inline-flex items-center gap-2 bg-white/10 border border-white/30 text-white font-medium px-5 py-2.5 rounded-lg text-sm hover:bg-white/20 transition-colors"
              data-testid="cta-download"
            >
              <Download className="w-4 h-4" />
              Tải Mẫu Nộp Bài
            </button>
          </div>
        </div>
      </div>

      <div className="px-6 lg:px-12 py-10 space-y-12 max-w-6xl">

        {/* ── SECTION 2: LETTER FROM PROFESSOR ── */}
        <section id="guidelines" data-testid="professor-letter">
          <div className="bg-card border border-border rounded-2xl overflow-hidden shadow-sm">
            <div className="bg-muted/40 border-b border-border px-6 py-4 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/15 flex items-center justify-center font-bold text-primary">GN</div>
              <div>
                <div className="text-sm font-semibold text-foreground">George Nguyen</div>
                <div className="text-xs text-muted-foreground">Serial Entrepreneur · Blockchain + AI · Giảng viên RMIT</div>
              </div>
              <div className="ml-auto text-xs text-muted-foreground italic">Lời ngỏ từ Giảng viên</div>
            </div>
            <div className="px-6 lg:px-10 py-8 space-y-4 text-sm leading-relaxed text-foreground">
              <p className="text-muted-foreground italic">Chào các học viên MBA,</p>
              <p>
                Xuyên suốt khóa học, chúng ta đã cùng nhau khám phá <strong>kỷ nguyên Augmented Era</strong>, nơi sự sáng tạo (Creativity) không chỉ là lợi thế mà là <em>kỹ năng sống còn</em>. Kỷ nguyên này đòi hỏi chúng ta phải áp dụng triết lý học tập mới:
              </p>
              <div className="flex items-center gap-3 bg-accent border border-accent-foreground/10 rounded-xl px-5 py-4 my-2">
                {["Learn · Học", "Unlearn · Loại bỏ lối mòn", "Relearn · Học lại kiến thức mới"].map((step, i) => (
                  <div key={i} className="flex items-center gap-3 flex-1">
                    <div className="w-7 h-7 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-xs shrink-0">{i + 1}</div>
                    <span className="text-sm font-medium text-accent-foreground">{step}</span>
                    {i < 2 && <span className="text-muted-foreground mx-1 text-lg hidden sm:block">→</span>}
                  </div>
                ))}
              </div>
              <p>
                Đối với đồ án cuối khóa này, tôi <strong>không tìm kiếm những bản tóm tắt lý thuyết sáo rỗng</strong>. Với tư cách là những nhà quản trị tương lai, kỳ vọng của tôi là các bạn phải <em>áp dụng thực tiễn</em> những công cụ như Design Thinking, 10 Giá trị cốt lõi hay 8 Bước quản trị sự thay đổi vào bối cảnh doanh nghiệp thực tế.
              </p>
              <p>
                Hãy thoát khỏi <strong>"Fachidiotism"</strong> (Bệnh chuyên môn hẹp) — nhìn xa hơn chuyên ngành của mình. Tư duy của một <em>Smart Creative</em> không bị giới hạn bởi ranh giới chức năng. Đây là cơ hội để các bạn chứng minh rằng mình không chỉ hiểu lý thuyết, mà còn có thể áp dụng nó để tạo ra giá trị thực sự.
              </p>
              <p className="text-muted-foreground italic border-l-2 border-primary pl-4">
                "The only way to discover the limits of the possible is to go beyond them into the impossible." — Arthur C. Clarke
              </p>
              <p className="font-medium text-foreground">Chúc các bạn thành công,<br /><span className="text-primary">George Nguyen</span></p>
            </div>
          </div>
        </section>

        {/* ── SECTION 3: PROJECT OPTIONS ── */}
        <section data-testid="project-options">
          <div className="mb-6">
            <h2 className="text-xl font-bold text-foreground font-serif">Cấu trúc Đồ án</h2>
            <p className="text-sm text-muted-foreground mt-1">
              Chọn <strong>1 trong 2</strong> hướng bên dưới. Tối đa <strong>10 slides (PowerPoint)</strong> hoặc <strong>10 trang Word</strong>. Trích dẫn chuẩn <strong>Harvard Style</strong>.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            {/* Card 1 */}
            <div
              onClick={() => setSelectedOption("innovation")}
              className={`relative bg-card border-2 rounded-2xl p-6 cursor-pointer transition-all hover:shadow-md
                ${selectedOption === "innovation" ? "border-primary shadow-md" : "border-border hover:border-primary/40"}`}
              data-testid="option-innovation"
            >
              {selectedOption === "innovation" && (
                <div className="absolute top-4 right-4">
                  <CheckCircle2 className="w-5 h-5 text-primary" />
                </div>
              )}
              <div className="flex items-start gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950/40 flex items-center justify-center shrink-0">
                  <Lightbulb className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <div className="text-xs font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider">Option 1</div>
                  <h3 className="text-base font-bold text-foreground">Innovation Project</h3>
                  <p className="text-xs text-muted-foreground">Đồ án Đổi mới Sáng tạo</p>
                </div>
              </div>
              <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                Tập trung vào một vấn đề chưa tồn tại, đang tồn tại hoặc giả định trên thị trường, và đưa ra giải pháp đột phá.
              </p>
              <div className="space-y-2.5">
                {[
                  "Xác định vấn đề (Pick your problem)",
                  "Áp dụng đủ 5 bước Design Thinking (Empathize → Define → Ideate → Prototype → Test)",
                  "Ứng dụng Creativity boosting techniques đã học",
                  "Đề xuất Innovative Solution",
                  "Tích hợp giải pháp vào Mô hình kinh doanh thực tế (Business Concept + Market Intelligence)",
                ].map((item, i) => (
                  <div key={i} className="flex items-start gap-2.5">
                    <div className="w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">{i + 1}</div>
                    <span className="text-xs text-foreground leading-snug">{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Card 2 */}
            <div
              onClick={() => setSelectedOption("change")}
              className={`relative bg-card border-2 rounded-2xl p-6 cursor-pointer transition-all hover:shadow-md
                ${selectedOption === "change" ? "border-primary shadow-md" : "border-border hover:border-primary/40"}`}
              data-testid="option-change"
            >
              {selectedOption === "change" && (
                <div className="absolute top-4 right-4">
                  <CheckCircle2 className="w-5 h-5 text-primary" />
                </div>
              )}
              <div className="flex items-start gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-violet-100 dark:bg-violet-950/40 flex items-center justify-center shrink-0">
                  <RefreshCw className="w-5 h-5 text-violet-600 dark:text-violet-400" />
                </div>
                <div>
                  <div className="text-xs font-bold text-violet-600 dark:text-violet-400 uppercase tracking-wider">Option 2</div>
                  <h3 className="text-base font-bold text-foreground">Change Management Project</h3>
                  <p className="text-xs text-muted-foreground">Đồ án Quản trị Sự thay đổi</p>
                </div>
              </div>
              <p className="text-sm text-muted-foreground mb-4 leading-relaxed">
                Áp dụng các nguyên lý quản trị sự thay đổi vào bối cảnh doanh nghiệp thực tế. Chọn 1 trong 2 track:
              </p>
              <div className="space-y-3">
                <div className="bg-violet-50 dark:bg-violet-950/20 border border-violet-200 dark:border-violet-900 rounded-xl p-3.5">
                  <div className="text-xs font-bold text-violet-700 dark:text-violet-400 mb-1">Track 2A — Personal Philosophy</div>
                  <p className="text-xs text-muted-foreground leading-snug">
                    Viết bài luận về "Triết lý Quản trị Sự thay đổi cá nhân". Trả lời: <em>Tại sao một tổ chức nên chọn TÔI làm Trưởng dự án dẫn dắt sự thay đổi?</em>
                  </p>
                </div>
                <div className="bg-violet-50 dark:bg-violet-950/20 border border-violet-200 dark:border-violet-900 rounded-xl p-3.5">
                  <div className="text-xs font-bold text-violet-700 dark:text-violet-400 mb-1">Track 2B — Industry Case Study</div>
                  <p className="text-xs text-muted-foreground leading-snug">
                    Phân tích một trường hợp thay đổi quy mô lớn (Apple/Jobs, Microsoft/Nadella, Tesla, Shell, hoặc công ty của bạn). Phân tích chiến lược và cách xử lý Resistance.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {selectedOption && (
            <div className="mt-4 flex items-center gap-2 text-sm text-primary bg-primary/5 border border-primary/20 rounded-xl px-4 py-3" data-testid="selection-confirm">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Bạn đã chọn <strong>{selectedOption === "innovation" ? "Option 1 — Innovation Project" : "Option 2 — Change Management Project"}</strong>. Xem rubric tương ứng bên dưới.</span>
            </div>
          )}
        </section>

        {/* ── SECTION 4: RUBRIC ── */}
        <section data-testid="grading-rubric">
          <div className="mb-5">
            <h2 className="text-xl font-bold text-foreground font-serif">Tiêu chí Chấm điểm</h2>
            <p className="text-sm text-muted-foreground mt-1">Cách thức để đạt điểm A — tự đánh giá trước khi nộp bài.</p>
          </div>

          {/* Rubric tab switcher */}
          <div className="flex gap-2 mb-5">
            {[
              { id: "innovation" as OptionId, label: "Option 1 · Innovation Project", icon: Lightbulb, color: "blue" },
              { id: "change" as OptionId, label: "Option 2 · Change Management", icon: RefreshCw, color: "violet" },
            ].map(({ id, label, icon: Icon, color }) => (
              <button
                key={id}
                onClick={() => setActiveRubric(id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium border transition-colors
                  ${activeRubric === id
                    ? color === "blue"
                      ? "bg-blue-600 text-white border-blue-600"
                      : "bg-violet-600 text-white border-violet-600"
                    : "bg-card text-muted-foreground border-border hover:text-foreground"
                  }`}
                data-testid={`rubric-tab-${id}`}
              >
                <Icon className="w-3.5 h-3.5" />
                {label}
              </button>
            ))}
          </div>

          {/* Innovation Rubric */}
          {activeRubric === "innovation" && (
            <div className="space-y-3" data-testid="rubric-innovation">
              <p className="text-xs text-muted-foreground">Tổng điểm tối đa: <strong>10 điểm</strong>. Thang điểm: 0 / 2 / 4 / 6 / 8 / 10.</p>
              {[
                {
                  weight: 2,
                  criterion: "Innovation Content",
                  sub: "Mức độ đổi mới của nội dung",
                  levels: [
                    { score: 10, label: "Outstanding", desc: "Innovation content very convincing — đột phá, rõ ràng, thuyết phục hoàn toàn" },
                    { score: 8, label: "Very Good", desc: "Innovation content fairly convincing — đủ thuyết phục, có chiều sâu" },
                    { score: 6, label: "Good", desc: "Some innovation content evident — có yếu tố đổi mới nhưng chưa rõ nét" },
                    { score: 4, label: "Average", desc: "Little innovation content — ít dấu hiệu đổi mới" },
                    { score: 2, label: "Below Avg", desc: "Hardly any innovation content — gần như không có" },
                    { score: 0, label: "Fail", desc: "No innovation content — không có" },
                  ],
                },
                {
                  weight: 1,
                  criterion: "Design Thinking Application",
                  sub: "Áp dụng 5 bước Design Thinking",
                  levels: [
                    { score: 10, label: "Outstanding", desc: "Addressed and applied well all 5 stages — đầy đủ, chính xác, sâu sắc" },
                    { score: 8, label: "Very Good", desc: "Addressed and applied correctly 4/5 stages" },
                    { score: 6, label: "Good", desc: "Either fail to address or apply some stages" },
                    { score: 4, label: "Average", desc: "Somehow understand but cannot apply all 5 stages" },
                    { score: 2, label: "Below Avg", desc: "Hardly understand and apply Design Thinking" },
                    { score: 0, label: "Fail", desc: "Need to re-work on concept — không nắm được" },
                  ],
                },
                {
                  weight: 1,
                  criterion: "Embedment in Business Concept",
                  sub: "Tích hợp giải pháp vào mô hình kinh doanh",
                  levels: [
                    { score: 10, label: "Outstanding", desc: "Innovation very convincingly embedded in business concept — hoàn toàn thuyết phục" },
                    { score: 8, label: "Very Good", desc: "Innovation embedded in business concept — tốt, logic" },
                    { score: 6, label: "Good", desc: "Innovation partially embedded — có tiềm năng nhưng chưa hoàn chỉnh" },
                    { score: 4, label: "Average", desc: "Innovation not well embedded in business concept" },
                    { score: 2, label: "Below Avg", desc: "Innovation hardly embedded — rất yếu" },
                    { score: 0, label: "Fail", desc: "Innovation not embedded in business concept" },
                  ],
                },
                {
                  weight: 1,
                  criterion: "Presentation",
                  sub: "Chất lượng trình bày",
                  levels: [
                    { score: 10, label: "Outstanding", desc: "Excellent and completely convincing — chuyên nghiệp, trực quan, thuyết phục" },
                    { score: 8, label: "Very Good", desc: "Good and reasonably convincing" },
                    { score: 6, label: "Good", desc: "Average and only partially convincing" },
                    { score: 4, label: "Average", desc: "Not particularly convincing" },
                    { score: 2, label: "Below Avg", desc: "Presentation was poor" },
                    { score: 0, label: "Fail", desc: "Very poor" },
                  ],
                },
              ].map((row) => (
                <RubricRow key={row.criterion} {...row} scheme="blue" />
              ))}
            </div>
          )}

          {/* Change Management Rubric */}
          {activeRubric === "change" && (
            <div className="space-y-3" data-testid="rubric-change">
              <p className="text-xs text-muted-foreground">Tổng điểm tối đa: <strong>10 điểm</strong>. Thang điểm: 2 / 4 / 6 / 8 / 10.</p>
              {[
                {
                  weight: 2,
                  criterion: "Identify Change Management Strategies",
                  sub: "Nhận diện các chiến lược quản trị sự thay đổi",
                  levels: [
                    { score: 10, label: "Distinguished", desc: "Demonstrates in-depth knowledge of change management strategies — sâu sắc, toàn diện" },
                    { score: 8, label: "Proficient", desc: "Demonstrates proficient knowledge of change management strategies" },
                    { score: 6, label: "Basic", desc: "Demonstrates basic knowledge of change management strategies" },
                    { score: 4, label: "Below Exp.", desc: "Demonstrates little to no knowledge of change management strategies" },
                    { score: 2, label: "Non-Perf.", desc: "Did not submit assignment" },
                  ],
                },
                {
                  weight: 1,
                  criterion: "Analyze Strategies in Change Scenarios",
                  sub: "Phân tích chiến lược trong bối cảnh thực tế",
                  levels: [
                    { score: 10, label: "Distinguished", desc: "Identifies strategy + in-depth knowledge of application to scenario. Relevant, supported by logic and detailed information" },
                    { score: 8, label: "Proficient", desc: "Identifies strategy + proficient knowledge of application. Relevant and supported with logic" },
                    { score: 6, label: "Basic", desc: "Identifies strategy, basic knowledge of application. Relevant to scenario" },
                    { score: 4, label: "Below Exp.", desc: "Identifies a strategy but did not demonstrate how it applies to the change scenario" },
                    { score: 2, label: "Non-Perf.", desc: "Did not submit assignment" },
                  ],
                },
                {
                  weight: 1,
                  criterion: "Presentation of Solutions (POA)",
                  sub: "Đề xuất giải pháp / Kế hoạch hành động",
                  levels: [
                    { score: 10, label: "Distinguished", desc: "In-depth solution/POA — relevant, supported by logic and detailed information" },
                    { score: 8, label: "Proficient", desc: "Proficient solution/POA — relevant, includes logic and support" },
                    { score: 6, label: "Basic", desc: "Basic/limited solution/POA — presented and relevant but no logic/support" },
                    { score: 4, label: "Below Exp.", desc: "Demonstrated knowledge of incorporation but no solution/POA presented" },
                    { score: 2, label: "Non-Perf.", desc: "Did not submit assignment" },
                  ],
                },
                {
                  weight: 1,
                  criterion: "Presentation Quality",
                  sub: "Chất lượng trình bày",
                  levels: [
                    { score: 10, label: "Distinguished", desc: "Excellent and completely convincing" },
                    { score: 8, label: "Proficient", desc: "Good and reasonably convincing" },
                    { score: 6, label: "Basic", desc: "Average and only partially convincing" },
                    { score: 4, label: "Below Exp.", desc: "Not particularly convincing" },
                    { score: 2, label: "Non-Perf.", desc: "Presentation was poor" },
                  ],
                },
              ].map((row) => (
                <RubricRow key={row.criterion} {...row} scheme="violet" />
              ))}
            </div>
          )}
        </section>

        {/* ── SECTION 5: FOOTER ── */}
        <section data-testid="project-footer">
          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            <div className="grid grid-cols-1 sm:grid-cols-3 divide-y sm:divide-y-0 sm:divide-x divide-border">
              <div className="px-6 py-5 flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-red-100 dark:bg-red-950/30 flex items-center justify-center shrink-0">
                  <Clock className="w-4 h-4 text-red-600 dark:text-red-400" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-0.5">Deadline</div>
                  <div className="text-sm font-bold text-foreground">15/05/2026</div>
                  <div className="text-xs text-muted-foreground">Hạn nộp cuối cùng</div>
                </div>
              </div>
              <div className="px-6 py-5 flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-blue-100 dark:bg-blue-950/30 flex items-center justify-center shrink-0">
                  <MapPin className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-0.5">Nơi nộp bài</div>
                  <div className="text-sm font-bold text-foreground">SSBM Portal</div>
                  <div className="text-xs text-muted-foreground">Cổng nộp bài chính thức</div>
                </div>
              </div>
              <div className="px-6 py-5 flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-amber-100 dark:bg-amber-950/30 flex items-center justify-center shrink-0">
                  <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-0.5">Lưu ý</div>
                  <div className="text-sm font-bold text-foreground">Harvard Citation</div>
                  <div className="text-xs text-muted-foreground">Trích dẫn bắt buộc đúng chuẩn</div>
                </div>
              </div>
            </div>
          </div>
        </section>

      </div>
    </div>
  );
}

// ─── RUBRIC ROW COMPONENT ────────────────────────────────────────────────────

interface RubricLevel {
  score: number;
  label: string;
  desc: string;
}

interface RubricRowProps {
  weight: number;
  criterion: string;
  sub: string;
  levels: RubricLevel[];
  scheme: "blue" | "violet";
}

const scoreColors: Record<number, string> = {
  10: "bg-emerald-500 text-white",
  8:  "bg-blue-500 text-white",
  6:  "bg-yellow-500 text-white",
  4:  "bg-orange-500 text-white",
  2:  "bg-red-400 text-white",
  0:  "bg-gray-400 text-white",
};

function RubricRow({ weight, criterion, sub, levels, scheme }: RubricRowProps) {
  const accentBg = scheme === "blue" ? "bg-blue-50 dark:bg-blue-950/20" : "bg-violet-50 dark:bg-violet-950/20";
  const accentText = scheme === "blue" ? "text-blue-700 dark:text-blue-400" : "text-violet-700 dark:text-violet-400";
  const weightBg = scheme === "blue" ? "bg-blue-600" : "bg-violet-600";

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      {/* Row header */}
      <div className={`flex items-center gap-4 px-5 py-4 ${accentBg} border-b border-border`}>
        <div className={`w-8 h-8 rounded-full ${weightBg} text-white flex items-center justify-center font-bold text-sm shrink-0`}>
          ×{weight}
        </div>
        <div className="flex-1 min-w-0">
          <div className={`text-sm font-bold ${accentText}`}>{criterion}</div>
          <div className="text-xs text-muted-foreground">{sub}</div>
        </div>
        <div className="flex items-center gap-1">
          <Star className="w-3.5 h-3.5 text-amber-500" />
          <span className="text-xs font-semibold text-foreground">Weight {weight}</span>
        </div>
      </div>

      {/* Level grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-0 divide-y sm:divide-y-0">
        {levels.map((level) => (
          <div key={level.score} className="flex gap-3 px-4 py-3.5 border-b border-r border-border last:border-b-0">
            <div className={`w-8 h-8 rounded-lg ${scoreColors[level.score]} flex items-center justify-center font-bold text-sm shrink-0`}>
              {level.score}
            </div>
            <div className="min-w-0">
              <div className="text-xs font-semibold text-foreground">{level.label}</div>
              <div className="text-xs text-muted-foreground leading-snug mt-0.5">{level.desc}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
