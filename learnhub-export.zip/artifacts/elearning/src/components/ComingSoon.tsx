import { Lock } from "lucide-react";
import type { Subject } from "@/data/courseData";

interface ComingSoonProps {
  subject: Subject;
}

export default function ComingSoon({ subject }: ComingSoonProps) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center gap-4 p-8 text-center" data-testid="coming-soon">
      <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
        <Lock className="w-7 h-7 text-muted-foreground" />
      </div>
      <div>
        <h2 className="text-xl font-semibold text-foreground">{subject.title}</h2>
        <p className="text-sm text-muted-foreground mt-1">{subject.code}</p>
      </div>
      <p className="text-sm text-muted-foreground max-w-xs">
        This course is not yet available. Check back at the start of next semester.
      </p>
      <span className="text-xs bg-muted text-muted-foreground px-3 py-1 rounded-full font-medium">
        Coming Soon
      </span>
    </div>
  );
}
