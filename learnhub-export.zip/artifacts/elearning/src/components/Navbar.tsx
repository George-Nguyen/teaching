import { useState } from "react";
import { ChevronDown, BookOpen, LogOut, User, Bell, Moon, Sun } from "lucide-react";
import { subjects, type Subject } from "@/data/courseData";

interface NavbarProps {
  currentSubject: Subject;
  onSubjectChange: (subject: Subject) => void;
  darkMode: boolean;
  onToggleDark: () => void;
}

export default function Navbar({ currentSubject, onSubjectChange, darkMode, onToggleDark }: NavbarProps) {
  const [subjectOpen, setSubjectOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80 shadow-sm">
      <div className="flex h-14 items-center px-4 gap-4">
        {/* Logo */}
        <div className="flex items-center gap-2 mr-4" data-testid="logo">
          <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
            <BookOpen className="w-4 h-4 text-primary-foreground" />
          </div>
          <span className="font-semibold text-sm hidden sm:block text-foreground">LearnHub</span>
        </div>

        {/* Subject Switcher */}
        <div className="relative" data-testid="subject-switcher">
          <button
            onClick={() => setSubjectOpen(!subjectOpen)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-md text-sm font-medium text-foreground hover:bg-muted transition-colors border border-border"
            data-testid="subject-dropdown-trigger"
          >
            <span className="text-muted-foreground text-xs font-normal hidden sm:inline">Môn học:</span>
            <span>{currentSubject.title}</span>
            <span className="text-xs text-muted-foreground bg-muted px-1.5 py-0.5 rounded font-mono hidden sm:inline">{currentSubject.code}</span>
            <ChevronDown className={`w-3.5 h-3.5 text-muted-foreground transition-transform ${subjectOpen ? "rotate-180" : ""}`} />
          </button>

          {subjectOpen && (
            <div className="absolute top-full left-0 mt-1.5 w-72 bg-card border border-border rounded-lg shadow-lg py-1.5 z-50" data-testid="subject-dropdown-menu">
              <div className="px-3 py-1.5 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                Danh sách Môn học
              </div>
              {subjects.map((subject) => (
                <button
                  key={subject.id}
                  onClick={() => {
                    if (subject.available) {
                      onSubjectChange(subject);
                      setSubjectOpen(false);
                    }
                  }}
                  disabled={!subject.available}
                  className={`w-full flex items-center justify-between px-3 py-2.5 text-sm text-left transition-colors
                    ${subject.available ? "hover:bg-muted cursor-pointer" : "opacity-40 cursor-not-allowed"}
                    ${currentSubject.id === subject.id ? "bg-accent text-accent-foreground" : "text-foreground"}
                  `}
                  data-testid={`subject-option-${subject.id}`}
                >
                  <div>
                    <div className="font-medium">{subject.title}</div>
                    <div className="text-xs text-muted-foreground mt-0.5">{subject.code}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    {currentSubject.id === subject.id && (
                      <span className="text-xs bg-primary text-primary-foreground px-2 py-0.5 rounded-full">Hiện tại</span>
                    )}
                    {!subject.available && (
                      <span className="text-xs bg-muted text-muted-foreground px-2 py-0.5 rounded-full">Sắp có</span>
                    )}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Spacer */}
        <div className="flex-1" />

        {/* Right side */}
        <div className="flex items-center gap-2">
          <button
            onClick={onToggleDark}
            className="p-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
            data-testid="toggle-dark-mode"
            aria-label="Toggle dark mode"
          >
            {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          <button className="p-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-muted transition-colors" data-testid="notifications-btn">
            <Bell className="w-4 h-4" />
          </button>

          <div className="flex items-center gap-2 pl-2 border-l border-border ml-1">
            <div className="w-7 h-7 rounded-full bg-primary/15 flex items-center justify-center" data-testid="user-avatar">
              <User className="w-3.5 h-3.5 text-primary" />
            </div>
            <div className="hidden sm:block">
              <div className="text-xs font-medium text-foreground leading-tight" data-testid="user-name">Alex Student</div>
              <div className="text-xs text-muted-foreground leading-tight">Học viên</div>
            </div>
            <button className="p-1.5 rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors ml-1" data-testid="logout-btn">
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Overlay */}
      {subjectOpen && (
        <div className="fixed inset-0 z-40" onClick={() => setSubjectOpen(false)} />
      )}
    </header>
  );
}
