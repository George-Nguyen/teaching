import { CheckCircle, Clock, PlayCircle } from "lucide-react";
import type { Lesson } from "@/data/courseData";

interface LessonSidebarProps {
  lessons: Lesson[];
  activeLesson: string;
  onSelectLesson: (lessonId: string) => void;
  completedLessons: Set<string>;
}

export default function LessonSidebar({ lessons, activeLesson, onSelectLesson, completedLessons }: LessonSidebarProps) {
  return (
    <nav className="w-56 lg:w-64 xl:w-72 shrink-0 bg-sidebar text-sidebar-foreground flex flex-col" data-testid="lesson-sidebar">
      <div className="px-4 py-3 border-b border-sidebar-border">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-sidebar-foreground/60">
          Nội dung Môn học
        </h3>
        <p className="text-xs text-sidebar-foreground/50 mt-1">
          {completedLessons.size} / {lessons.length} đã hoàn thành
        </p>
      </div>

      {/* Progress bar */}
      <div className="px-4 py-2 border-b border-sidebar-border">
        <div className="w-full bg-sidebar-accent rounded-full h-1.5">
          <div
            className="bg-sidebar-primary h-1.5 rounded-full transition-all duration-500"
            style={{ width: `${(completedLessons.size / lessons.length) * 100}%` }}
            data-testid="progress-bar"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto py-2">
        {lessons.map((lesson, idx) => {
          const isActive = lesson.id === activeLesson;
          const isCompleted = completedLessons.has(lesson.id);

          return (
            <button
              key={lesson.id}
              onClick={() => onSelectLesson(lesson.id)}
              className={`w-full text-left px-4 py-3 flex items-start gap-3 lesson-nav-item border-l-3 transition-all
                ${isActive
                  ? "bg-primary/10 border-l-sidebar-primary"
                  : "border-l-transparent hover:bg-sidebar-accent"
                }
              `}
              data-testid={`lesson-nav-${lesson.id}`}
              style={{
                borderLeftWidth: isActive ? "3px" : "3px",
                borderLeftColor: isActive ? "hsl(var(--sidebar-primary))" : "transparent",
              }}
            >
              <div className="shrink-0 mt-0.5">
                {isCompleted ? (
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                ) : isActive ? (
                  <PlayCircle className="w-4 h-4 text-sidebar-primary" />
                ) : (
                  <div className="w-4 h-4 rounded-full border-2 border-sidebar-foreground/30 flex items-center justify-center">
                    <span className="text-[9px] font-bold text-sidebar-foreground/50">{idx + 1}</span>
                  </div>
                )}
              </div>
              <div className="min-w-0">
                <div className={`text-sm font-medium leading-snug ${isActive ? "text-sidebar-primary" : "text-sidebar-foreground"}`}>
                  {lesson.title}
                </div>
                <div className="flex items-center gap-1 mt-1">
                  <Clock className="w-3 h-3 text-sidebar-foreground/40" />
                  <span className="text-xs text-sidebar-foreground/40">{lesson.duration}</span>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
