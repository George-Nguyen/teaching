import { Award, AlertCircle, CheckCircle2 } from "lucide-react";
import type { Course } from "@/data/courseData";

interface GradingTabProps {
  course: Course;
}

export default function GradingTab({ course }: GradingTabProps) {
  const { grading } = course;

  return (
    <div className="p-6 lg:p-8" data-testid="grading-tab">
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 max-w-7xl mx-auto">

        {/* LEFT — main grading info */}
        <div className="xl:col-span-2 space-y-5">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Award className="w-5 h-5 text-primary" />
              <h1 className="text-xl font-bold text-foreground">Hệ thống Chấm điểm</h1>
            </div>
            <p className="text-sm text-muted-foreground">
              Điểm cuối kỳ của bạn được xác định bởi hiệu suất tích lũy qua tất cả bài tập, bài kiểm tra và sự tham gia.
            </p>
          </div>

          {/* Grade Components */}
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="px-5 py-3.5 bg-muted/50 border-b border-border">
              <h2 className="text-sm font-semibold text-foreground">Thành phần Điểm số</h2>
            </div>
            <div className="divide-y divide-border">
              {[
                { item: "Bài tập & Phản ánh", weight: "30%", status: "ongoing", desc: "Phản ánh viết hàng tuần và bài tập bài học" },
                { item: "Dự án Giữa kỳ", weight: "25%", status: "upcoming", desc: "Thuyết trình nhóm về một trường hợp đổi mới" },
                { item: "Thuyết trình Cuối kỳ", weight: "30%", status: "upcoming", desc: "Dự án quản lý sự thay đổi — bài nộp nhóm đầy đủ" },
                { item: "Tham gia & Thảo luận", weight: "15%", status: "ongoing", desc: "Tham gia trong lớp và đóng góp cho nhóm bạn" },
              ].map(({ item, weight, status, desc }) => (
                <div key={item} className="px-5 py-4" data-testid={`grade-component-${item.replace(/\s+/g, "-").toLowerCase()}`}>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      <CheckCircle2 className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                      <div>
                        <div className="text-sm font-medium text-foreground">{item}</div>
                        <div className="text-xs text-muted-foreground mt-0.5">{desc}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium whitespace-nowrap ${
                        status === "ongoing"
                          ? "bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400"
                          : "bg-muted text-muted-foreground"
                      }`}>
                        {status === "ongoing" ? "Đang diễn ra" : "Sắp tới"}
                      </span>
                      <span className="text-sm font-bold text-foreground font-mono w-10 text-right">{weight}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Pass Condition */}
          <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900 rounded-xl p-5" data-testid="pass-condition">
            <div className="flex gap-3">
              <AlertCircle className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              <div>
                <h3 className="text-sm font-semibold text-amber-800 dark:text-amber-300 mb-1">Điều kiện Qua môn</h3>
                <p className="text-sm text-amber-700 dark:text-amber-400 leading-relaxed">
                  {grading.passCondition}
                </p>
              </div>
            </div>
          </div>

          {/* Final Tasks highlight */}
          <div className="bg-red-50 dark:bg-red-950/20 border-2 border-red-300 dark:border-red-800 rounded-xl p-5">
            <h3 className="text-sm font-bold text-red-700 dark:text-red-400 mb-3 flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              Bài tập Cuối khóa (Chương 7)
            </h3>
            <div className="space-y-3">
              <div className="flex gap-3">
                <span className="w-6 h-6 rounded-full bg-red-200 dark:bg-red-900 text-red-700 dark:text-red-300 flex items-center justify-center text-xs font-bold shrink-0">1</span>
                <div>
                  <div className="text-sm font-medium text-foreground">Bài luận Cá nhân (1.000–1.500 từ)</div>
                  <div className="text-xs text-muted-foreground mt-0.5">Triết lý quản lý sự thay đổi cá nhân của bạn — tại sao người khác muốn bạn dẫn dắt?</div>
                </div>
              </div>
              <div className="flex gap-3">
                <span className="w-6 h-6 rounded-full bg-red-200 dark:bg-red-900 text-red-700 dark:text-red-300 flex items-center justify-center text-xs font-bold shrink-0">2</span>
                <div>
                  <div className="text-sm font-medium text-foreground">Nghiên cứu Trường hợp (1.200–2.000 từ)</div>
                  <div className="text-xs text-muted-foreground mt-0.5">Tìm và phân tích một sự thay đổi tổ chức lớn trong thực tế (ví dụ: Apple, Netflix, Microsoft dưới Nadella).</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT — grade scale sidebar */}
        <div className="space-y-5">
          <div className="bg-card border border-border rounded-xl overflow-hidden" data-testid="grade-scale">
            <div className="px-5 py-3.5 bg-muted/50 border-b border-border">
              <h2 className="text-sm font-semibold text-foreground">Thang điểm</h2>
            </div>
            <div className="divide-y divide-border">
              {grading.scale.map((entry) => (
                <div key={entry.grade} className="flex items-center justify-between px-5 py-4" data-testid={`grade-entry-${entry.grade}`}>
                  <div className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-lg ${entry.color} flex items-center justify-center`}>
                      <span className="text-white font-bold">{entry.grade}</span>
                    </div>
                    <span className="text-sm font-medium text-foreground">Loại {entry.grade}</span>
                  </div>
                  <span className="text-sm text-muted-foreground font-mono">{entry.range}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Tips */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h3 className="text-sm font-semibold text-foreground mb-3">Mẹo để Thành công</h3>
            <div className="space-y-2.5">
              {[
                "Nộp tất cả bài tập trước hạn nộp bài đầu tiên",
                "Tham gia tích cực trong mỗi buổi thảo luận",
                "Áp dụng các khung vào ví dụ thực tế bạn biết",
                "Thành lập nhóm dự án sớm (Chương 6)",
                "Đọc ít nhất một cuốn sách được đề xuất từ đầu đến cuối",
              ].map((tip, i) => (
                <div key={i} className="flex items-start gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
                  <span className="text-xs text-muted-foreground leading-relaxed">{tip}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
